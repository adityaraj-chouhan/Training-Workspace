import React from 'react';
 
function About () {
    return <div>
        <h2>YASH TECHNOLOGIES</h2>
 
        Read more about us at :
        <a href="https://www.yash.com/">
        https://www.yash.com
        </a>
    </div>
}
export default About;