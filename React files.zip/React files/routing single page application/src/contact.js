import React from 'react';
 
function Contact (){
 return <address>
            crystal it park ,indore
        </address>
}
 
export default Contact;