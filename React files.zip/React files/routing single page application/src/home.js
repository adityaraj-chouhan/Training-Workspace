import React from 'react';
 
function Home (){
    return <h1>Hello- Yash Techologies</h1>
}
 
export default Home;