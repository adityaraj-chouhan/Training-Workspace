import React from 'react'
  
const Search = () => {
  return (
    <div className='Search'>
      <h2>You are inside the Search Component</h2>
 
    </div>
  )
}
  
export default Search