import React from 'react'
  
const Home = () => {
  return (
    <div className="Page">
      <h1>You are in the Home page!</h1>
     
    </div>
  )
}
  
export default Home