
import React, {Component} from 'react';
class Testimonial extends Component
{
  render()
  {
    return (
        <div className='testimonial'>
            <ul>
            <li>Content 1</li>          

            </ul>
        </div>

    );
  }
}
export default Testimonial