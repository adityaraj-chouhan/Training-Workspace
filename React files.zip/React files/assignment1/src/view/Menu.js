import React, {Component} from 'react';
class Menu extends Component
{
  render()
  {
    return (
        <div className='navbar'>
               

        </div>

    );
  }
}
export default Menu