import React, {Component} from 'react';
class RightContent extends Component
{
  render()
  {
    return (
        <div className='rcontent'>
                 
  Big Image
        </div>

    );
  }
}
export default RightContent