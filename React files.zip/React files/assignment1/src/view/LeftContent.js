import React, {Component} from 'react';
class LeftContent extends Component
{
  render()
  {
    return (
        <div className='lcontent'>
                 
  logo of company
        </div>

    );
  }
}
export default LeftContent