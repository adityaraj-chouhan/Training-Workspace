import React, {Component} from 'react';
class News extends Component
{
  render()
  {
    return (
        <div className='news'>
            <ul>
            <li>Query form</li>
            

            </ul>
        </div>

    );
  }
}
export default News