import Menu from './view/Menu';
import LeftContent from './view/LeftContent';
import RightContent from './view/RightContent';
import News from './view/News';
import Testimonial from './Testimonial';
import LoginForm from './LoginForm';
import './App.css';

function App() {
  return (
     <div className='wrapper'>
   <Menu />
   <div className='content'>
   <LeftContent />
   <RightContent />
   </div>
   <div className='footertop'>
    <News />
    <Testimonial />
<LoginForm />
   </div>
   </div>
  );
}

export default App;
