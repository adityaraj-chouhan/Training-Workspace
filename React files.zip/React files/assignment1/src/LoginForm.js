
import React, {Component} from 'react';
class LoginForm extends Component
{
  render()
  {
    return (
        <div className='loginform'>
     Content 2
        </div>

    );
  }
}
export default LoginForm