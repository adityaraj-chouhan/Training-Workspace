
import React, {Component} from 'react';
class QueryForm extends Component
{
  render()
  {
    return (
        <div className='queryform'>
            <form>
                <label>Name<input type="text" /></label>
                <br />
                <label>Query<input type="text" /></label> 
                <br />
                <input type="submit" value="Submit" />
            </form>
        </div>

    );
  }
}
export default QueryForm