import React, {Component} from 'react';
class Content1 extends Component
{
  render()
  {
    return (
        <div className='content1'>
                 
  Content1
        </div>

    );
  }
}
export default Content1