import React, {Component} from 'react';
class Logo extends Component
{
  render()
  {
    return (
        <div className='logo'>
            <ul>
            <li>Monsoon is touching indore</li>
            <li>mnc election is going on</li>

            </ul>
        </div>

    );
  }
}
export default Logo