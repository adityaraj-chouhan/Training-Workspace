import React, {Component} from 'react';
class Content2 extends Component
{
  render()
  {
    return (
        <div className='content2'>
                 
  Content2
        </div>

    );
  }
}
export default Content2