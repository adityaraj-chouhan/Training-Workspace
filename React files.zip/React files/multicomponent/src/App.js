import Menu from './view/Menu';
import Content1 from './view/Content1';
import Content2 from './view/Content2';
import Logo from './view/Logo';
import Image from './view/Image';
import QueryForm from './QueryForm';
import './App.css';

function App() {
  return (
    
     <div className='wrapper'>
      <div>
   <Logo />
   
   <Menu />
   <div className='footertop'>
   <QueryForm/>
   </div>
   </div>
   <div>
    <Image/>
   <div className='content'>
   <Content1 />
   <Content2 />
   </div>
   </div>
   </div>
  );
}

export default App;
