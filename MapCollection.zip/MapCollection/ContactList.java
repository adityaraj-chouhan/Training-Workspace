import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class ContactList {
	public static void main(String[] args) {
		HashMap<String ,Integer>ContactList = new HashMap<>();

		ContactList.put("474358564",1);
		ContactList.put("124390658",2);
		ContactList.put("458906",3);
		ContactList.put("453908906",4);
		ContactList.put("4367895673",5);
		ContactList.put("65784904",4);
		int v= 4;
		System.out.println( ContactList);


		Iterator<Map.Entry<String ,Integer> >
		iterator = ContactList.entrySet().iterator();
		String k="810972349";
		boolean key = false;
		boolean val=false;

		while (iterator.hasNext()) {
			Map.Entry<String ,Integer> entry= iterator.next();
			System.out.println("Key :"+entry.getKey()+" "+entry.getValue());

			if (k == entry.getKey()) {
				key = true;
			}
			if (v == entry.getValue()) {
				val = true;
				}
			}
		System.out.println("value preswnt "+key);
		System.out.println("key preswn "+val);

	}
}

