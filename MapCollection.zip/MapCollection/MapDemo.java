import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {
	public static void main(String[] args) {
		Map map= new HashMap();
		map.put(10,"adi");
		map.put(11,"raj");
		map.put(20,"singh");
		Set s=map.entrySet();// convert to set to traverse
		Iterator i=s.iterator();
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();// value sepration
			System.out.println("key:"+entry.getKey()+"Value:"+entry.getValue());
		}
		
		
	}

}
