import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class StatesAndCapital {
	public static void main(String[] args) {
		HashMap<String, String>
		hm = new HashMap<>();
		hm.put("Madhya Pradesh","Bhopal");
		hm.put("Maharastra","Mumbai");
		hm.put("Uttar Pradesh","Lucknow");
		hm.put("Punjab","Chandigarh");
		hm.put("Bihar","Patna");
		System.out.println( hm);
		Iterator<Map.Entry<String, String> > i = hm.entrySet().iterator();
		while (i.hasNext()) {
			Map.Entry<String, String>entry= i.next();
			System.out.println("Key :"+entry.getKey()+" Value "+entry.getValue());
		}
	}
}



