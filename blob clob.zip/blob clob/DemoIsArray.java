class DemoIsArray
{
public static void main(String[] args)throws Exception{
Class c =Class.forName("A");
System.out.println("class represented by c is"+c.toString());
System.out.println("is a an array"+c.isArray());

}
}