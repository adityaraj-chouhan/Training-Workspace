class A{}
interface b{}
class DemoForName
{
public static void main(String[] args) throws Exception{
Class c =Class.forName("A");
System.out.println(c.isInterface());
Class c1 =Class.forName("b");
System.out.println(c1.isInterface());
}
}