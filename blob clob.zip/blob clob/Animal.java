import java.lang.Class;
import java.lang.reflect.*;

public class  Animal {
	public void display() {
		System.out.println("I am a dog.");
	}
}

class Main {
	public static void main(String[] args) {
		try {
			Animal d1 = new Animal();
			Class c=Class.forName("Animal");
			System.out.println(c.getName());
			Class obj = d1.getClass();

			String name = obj.getName();
			System.out.println("Name: " + name);

			int modifier = obj.getModifiers();

			String mod = Modifier.toString(modifier);
			System.out.println("Modifier: " + mod);
			
			Class superClass = obj.getSuperclass();
			System.out.println("Superclass: " + superClass.getName());
    

		}

		catch (Exception e) {
		e.printStackTrace();
		}
	}
}