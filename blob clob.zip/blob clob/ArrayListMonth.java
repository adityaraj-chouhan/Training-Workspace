import java.util.ArrayList;
public class ArrayListMonth {
	public static void main(String[] args) {
		ArrayList a= new ArrayList();
		a.add("jan");
		a.add("feb");
		a.add("march");
		System.out.println(a);
	}

}
