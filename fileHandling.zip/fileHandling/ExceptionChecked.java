import java.io.*;

class ExceptionChecked
{
	public static void main(String []args) throws FileNotFoundException
	{	
		
		FileInputStream  f=null;
		try
		{ ExceptionChecked t =new ExceptionChecked();
				t.show();
			f= new FileInputStream("d:/yash/xyzz.txt");
			class a =Class.forName("Adi");
		}
		catch(FileNotFoundException e)
		{
			System.out.print("file does not exist");
		}
		catch(ClassNotFoundException e)
		{
			System.out.print("class does not exist");
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}

		