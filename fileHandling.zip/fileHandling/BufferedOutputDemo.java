import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
class BufferedOutputDemo
{
	public static void main(String[] args) 
    {
		try
		{
		FileInputStream fin=new FileInputStream("d:/yash/xyz.txt");
		FileOutputStream out= new FileOutputStream("d:/yash/abc.txt");
		BufferedInputStream binput = new BufferedInputStream(fin);
		int i;
		
		while((i=binput.read())!=-1)
		{
			out.write(i);
			System.out.print((char)i);
		}
		binput.close();
		fin.close();
		out.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
		