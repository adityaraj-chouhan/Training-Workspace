import java.io.FileInputStream;
import java.io.*;
class CountCharacter
{
	public static void main(String[] args) throws IOException
    {
		File f =new File("d:/yash/xyz.txt");
		FileInputStream fi=new FileInputStream(f);
		InputStreamReader is=new InputStreamReader(fi);
		BufferedReader br = new BufferedReader(is);
		String l;
		int word=0;
		int sentence=0;
		int character=0;
		int space=0;
		while((l=br.readLine())!=null)
		{
			if(!(l.equals("")))
			{
				character= character+l.length();
				String[] wordList=l.split("/s+");
				word=word+wordList.length;
				space=space+word-1;
				String[] sentenceList= l.split("[!?.:]+");
				sentence =sentenceList.length;
			}
		}
		System.out.println(" word"+ word);
		System.out.println(" sentence"+ sentence);
		System.out.println(" character"+ character);
		System.out.println(" space"+ space);
		
		
		
		
	}
}
		