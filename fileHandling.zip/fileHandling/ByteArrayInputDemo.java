import java.io.FileInputStream;
import java.io.ByteArrayInputStream;
class ByteArrayInputDemo
{
	public static void main(String[] args) throws Exception
    {
		
		byte[] b={1,4,5,9};
		ByteArrayInputStream di = new ByteArrayInputStream(b);
		int i;
		while((i=di.read())!=-1)
		{
			
			System.out.print(i);
		}
		di.close();

	
		
	}
}
		