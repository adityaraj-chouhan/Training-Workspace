import java.io.*;
class CharacterCountFile
{
	public static void main(String args[]) throws Exception
	{	
		int count=0;
		FileInputStream f1 = new FileInputStream("d:/yash/xyz.txt");
		String str="";
        int m;
		while((m=f1.read())!=-1)
		{
			str +=(char)m;
		}
		f1.close();
		System.out.println(str);
		String str1= str.toLowerCase();
		int freq[] = new int[256];
		for(int i = 0; i<str1.length() ; i++)
		{
			if(str1.charAt(i)=='a')
			{
				count=count+1;
			}
			
			
		}

		System.out.println(count); 
		}
		}
	
