import java.io.FileInputStream;
import java.io.DataInputStream;
class DataInputDemo
{
	public static void main(String[] args) throws Exception
    {
		
		FileInputStream fin=new FileInputStream("d:/yash/xyz.txt");
		DataInputStream di = new DataInputStream(fin);
		int i;
		while((i=di.read())!=-1)
		{
			
			System.out.print((char)i);
		}
		di.close();
		fin.close();
	
		
	}
}
		