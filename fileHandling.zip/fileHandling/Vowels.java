
import java.io.*;
class Vowels
{
	public static void main(String args[]) throws Exception
	{
		FileInputStream f1 = new FileInputStream("d:/yash/xyz.txt");
		String str="";
		int m;
		while((m=f1.read())!=-1)
		{
			str +=(char)m;
		}
		f1.close();
		System.out.println(str);
		int a=0,e=0,i=0,u=0,o=0;
		for(int j=0;j<str.length();j++)
		{
			char ch=str.charAt(j);
			if(ch=='a' || ch=='A')
			{
				a++;
			}
			else if (ch=='e' || ch=='E')
			{
				e++;
			}
			else if (ch=='i' || ch=='I')
			{
				i++;
			}
			else if (ch=='u' || ch=='U')
			{
				u++;
			}
			else if (ch=='o' || ch=='O')
			{
				o++;
			}
		}
		int vowels = a+e+i+o+u;
		System.out.println("Total vowels "+vowels);
		System.out.println("a "+a);
		System.out.println("e "+e);
		System.out.println("i "+i);
		System.out.println("u "+u);
		System.out.println("o "+o);
	}
}





