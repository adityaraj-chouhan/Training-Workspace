import java.io.*;
class ExceptionUnchecked
{
	public static void main(String []args)
    {	
		
		try
		{
			
			int a[]={1,2,3,4,5};
			a[5]=30/0;
			for(int i=0;i<=a.length;i++)
			{
			System.out.println(a[i]+" ");
			}
			
			
			String b=null;
			if(b.equals("adi"))
			{
				System.out.println("same");
			}
			else
			{
				System.out.println("not same");
			}			
			
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("out of index check code");
		}
		
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
		}
		catch(NullPointerException e)
		{
			System.out.println(e.getMessage());
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		
	}
}

