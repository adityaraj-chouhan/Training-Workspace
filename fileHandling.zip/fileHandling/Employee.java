import java.io.*;
class Employee implements Serializable 
{
	int empid;
	String empName;
	Employee(int empid,String empName)
	{
		this.empId=empId;
		this.empName=empName;
	}
	public String to String()
	{
		return empId + " " + empName;
	}
}
class EmployeeObjectInputDemo
{
	public static void main(String[] args) throws Exception
    {
		Employee e=new Employee(1, "adi");
		System.out.println(e);
		File f =new File("d:/yash/abc.txt");
		
		
		
		ObjectOutputStream oos= new ObjectOutputStream(new FileOutputStream));
		oos.writeObject(e);
		oos.close();
	}
}