import java.io.*;
class Employee2 implements Serializable 
{
	int empId;
	String empName;
	Employee2(int empId,String empName)
	{
		this.empId=empId;
		this.empName=empName;
	}
	public String toString()
	{
		return empId + " " + empName;
	}
}
class EmployeeObjectiInputDemo
{
	public static void main(String[] args) throws Exception
    {
		
		File f =new File("d:/yash/abc.txt");
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));
		Employee2 e =(Employee2)ois.readObject();
		ois.close();
		System.out.println(e);
	
	}
}