import java.io.*;
import java.util.Scanner;
class Employee3 implements Serializable 
{
	String name;
	String department;
	String designation;
	Double salary;
	Employee3(String name ,String department,String Designation,Double salary)
	{
		this.name=name;
		this.department=department;
		this.designation=designation;
		this.salary=salary;
		
	}
	public String toString()
	{
		return name + " " + department+ " "+ designation + " "+ salary;
		
	}
}
class Employee3Info
{
	public static void main(String[] args) throws Exception
    {
		Scanner input = new Scanner(System.in);
		System.out.println("enter name");
		String name = input.nextLine();
		System.out.println("enter department");
		String department = input.nextLine();
		System.out.println("enter designation ");
		String designation= input.nextLine();
		System.out.println("enter salary ");
		double salary= input.nextDouble();
		
		Employee3 e=new Employee3(name,department,designation,salary);
		
		File f =new File("d:/yash/yash.txt");
		ObjectOutputStream oos= new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));
		ois.readObject();
		ois.close();
		System.out.println(e);
		
	}
}
		
