public class EnumSeasons{
enum Seasons
{
	SUMMER(1),WINTER(2),FALL(3),SPRING(4);
	int val;
	Seasons(int val)
	{
		this.val=val;
	}
}


	public static void main(String[] args) 
    {

		for(Seasons s:Seasons.values())
		{
			System.out.println(s+ " "+s.val);
		}
	}

}