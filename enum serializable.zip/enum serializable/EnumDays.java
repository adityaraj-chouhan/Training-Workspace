public class EnumDays{
enum Days
{
	MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY;
	
}


	public static void main(String[] args) 
    {
		Days[] EnumDays=Days.values();
		for(Days d:Days.values())
		{
			switch(d)
			{
				case MONDAY: System.out.println("monday");
					System.out.println("index of " +Days.valueOf("MONDAY").ordinal());
				break;
				case TUESDAY: System.out.println("TUES");
					System.out.println("index of " +Days.valueOf("TUESDAY").ordinal());
				break;
				case WEDNESDAY: System.out.println("wed");
				System.out.println("index of " +Days.valueOf("WEDNESDAY").ordinal());
				break;
				case THURSDAY: System.out.println("thurs");
					System.out.println("index of " +Days.valueOf("THURSDAY").ordinal());
				break;
				case FRIDAY: System.out.println("fri");
				System.out.println("index of " +Days.valueOf("FRIDAY").ordinal());
				break;
				case SATURDAY: System.out.println("sat");
				System.out.println("index of " +Days.valueOf("SATURDAY").ordinal());
				break;
				case SUNDAY: System.out.println("sun");
				System.out.println("index of " +Days.valueOf("SUNDAY").ordinal());
				break;
			}
		}
	}

}