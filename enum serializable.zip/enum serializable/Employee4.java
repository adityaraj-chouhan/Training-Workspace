import java.util.Scanner;
import java.io.*;
class Employee4 implements Serializable 
{
	String name;
	String department;
	String designation;
	Double salary;
	
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getDepartment()
	{
		return department;
	}
	public void setDepartment(String department)
	{
		this.department=department;
	}
	public String getDesignation()
	{
		return designation;
	}
	public void setDesignation(String designation)
	{
		this.designation=designation;
	}
	public Double salary()
	{
		return salary;
	}
	public void setSalary(Double salary)
	{
		this.salary=salary;
	}
	public String toString()
	{
		return name+ " " + department+ " "+ designation+" "+ salary;
	}
}
	
	class Employee4Info
{
	public static void main(String[] args) throws Exception
    {
		Scanner input = new Scanner(System.in);
		System.out.println("enter name");
		String name = input.nextLine();
		System.out.println("enter department");
		String department = input.nextLine();
		System.out.println("enter designation ");
		String designation= input.nextLine();
		System.out.println("enter salary ");
		double salary= input.nextDouble();
		
	
		
		Employee4 e=new Employee4();
		System.out.println(e);
		File f =new File("d:/yash/yash.txt");
		ObjectOutputStream oos= new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
		
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));
		Employee4 m =(Employee4)ois.readObject();
		ois.close();
		System.out.println(m);
		
			
	}
}