abstract class GeneralBank
{
	abstract double getSavingsInterestRate();
	
	abstract double getFixedDepositInterestRate();
	
}
class ICICIBank extends GeneralBank
{
	double getSavingsInterestRate()
	{
		return 4;
	}
	double getFixedDepositInterestRate()
	{
		return 8.5;
	}
	
}

class SBIBank extends GeneralBank
{
	double getSavingsInterestRate()
	{
		return 4;
	}
	double getFixedDepositInterestRate()
	{
		return 7;
	}
}

class Main
{
	public static void main(String[] args)
	{
	ICICIBank i = new ICICIBank();
	SBIBank s =new SBIBank();
	GeneralBank g= new SBIBank();
	System.out.println(" icici has"+ i.getFixedDepositInterestRate());
	System.out.println(" sbi has"+ s.getFixedDepositInterestRate());
	System.out.println("icici has "+ i.getSavingsInterestRate());
	System.out.println("sbi has  "+ s.getSavingsInterestRate());
	
	}
	}
	