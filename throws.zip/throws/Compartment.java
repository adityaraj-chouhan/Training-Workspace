import java.util.Random ;
abstract class Compartment
{
	public abstract String notice();
}

class FirstClass extends Compartment
{
	public String notice()
	{
	 return "you are in firstclass";
	}
}

class Ladies extends Compartment
{
	public String notice()
	{
	return "you are in Ladies";
	}
}

class General extends Compartment
{
	public String notice()
	{
	return " you are in general";
	}
}

class Luggage extends Compartment
{
	public String notice()
	{
	return "you are in luggage";
	}
}

class TestCompartment
{
	public static void main(String[] args)
	{
		 Compartment[] c=new Compartment[10];
		 Random random= new Random();
		 for(int i=0;i<10;i++)
		 {
		 int r =random.nextInt((4-1)+1)+1;
		 if (r==1)
		 {
		 c[i]= new FirstClass();
		 }
		  else if (r==2)
		 {
		 c[i]= new Ladies();
		 }
		  else if (r==3)
		 {
		 c[i]= new General();
		 }
		 else if (r==4)
		 {
		 c[i]= new Luggage();
		 }
		 System.out.println(c[i].notice());
		 }
	}
	
}	
	