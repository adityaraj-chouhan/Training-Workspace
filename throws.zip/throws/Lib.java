interface LibraryUser
{
	void registerAccount();
	void requestBook();
}



class Kid implements LibraryUser
{
	int age;
	String bookType;

	void set(int age,String bookType)
	{
		this.age=age;
		this.bookType=bookType;
	}


	public void registerAccount()
	{
		if(age<12)
		{
			System.out.println("You have succesfully registerd under kids accn ");
		}
		else
		{
			System.out.println("age must be less than 12 for kid accn ");
		}	

	}
	public void requestBook()
	{
		if(bookType.equals("Kids"))
		{
			System.out.println("book issued , return in 10 days ");
		}
		else {
			System.out.println("oops you are not allowes in akids ");
		}
	}



}



class Adult implements LibraryUser
{
	int age;
	String bookType;
	void set(int age,String bookType)
	{
		this.age=age;
		this.bookType=bookType;
	}

	public void registerAccount()
	{
		if(age>12)
		{
			System.out.println("You have succesfully registerd under Adult accn ");
		}
		else{
			System.out.println("age must be more than 12 for adult accn ");
		}

	}
	public void requestBook()
	{
		if(bookType.equals("Fiction"))
		{
			System.out.println("book issued , return in 7 days ");
		}
		else {
			System.out.println("oops you are allowed only to take adult fiction books ");
		}
	}


}




class Lib
{
	public static void main(String args[])
	{
		Kid k = new Kid();
		k.set(8,"Kids");
		k.registerAccount();
		k.requestBook();
		Adult a= new Adult();
		a.set(65,"Fiction");
		a.registerAccount();
		a.requestBook();


	}
}