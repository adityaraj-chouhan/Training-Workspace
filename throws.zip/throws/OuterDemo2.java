class Outer
{
	void show1()
	{
		System.out.println("outer show1");
	}
	static class Inner
	{
		void show()
		{
			System.out.println("outer show");
		}
	}
}
public class OuterDemo2
{
	public static void main(String[] args )
	{
		
		Outer.Inner oi =new Outer.Inner();
		oi.show();
		//oi.show1();
	}
}
		