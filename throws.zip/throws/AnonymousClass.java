interface Age
{
	int x=2;
	void show();
}

Class MyAge implements Age
{
	public void show()
	{
		System.out.println(" "+ x);
	}
}
class AnonymousClass
{
	public static void main(String[] args )
	{
		MyAge obj =new MyAge();
		obj.show();
	}
}
	

