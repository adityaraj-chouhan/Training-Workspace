import comautomobile;
class Test{
	public static void main(args[] ar){
		Hero h1 = new Hero();
		System.out.print(h1.getModel() + " registration number=" + h1.getRegistration() + " is moving with speed of " + h1.getSpeed().toString());
	}
}

