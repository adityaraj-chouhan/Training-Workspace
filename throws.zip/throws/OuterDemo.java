class Outer
{	
	class Inner
	{
		void show()
		{
			System.out.println("outer show");
		}
	}
}
public class OuterDemo
{
	public static void main(String[] args )
	{
		Outer o= new Outer();
		Outer.Inner oi =o.new Inner();
		oi.show();
	}
}
		