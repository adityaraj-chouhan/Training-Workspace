import java.io.*;
class Throws2
	{
	void show() throws IOException
		{ 
		int a;
		}
	}
class Throws3
		{
		public static void main(String[] args)
			{
			Throws2 t=new Throws2();
			try{
				t.show();
				
				}
			catch(IOException e)
				{
				e.printStackTrace();
				}
				System.out.println("normal termination");
			}
		}