package comautomobile ;
abstract class Vehicle{
	public abstract String getModel();
	public abstract String getRegistrationNumber();
	public abstract String getOwner();
}

class Hero extends Vehicle{

	int speed = 40;

	public int getSpeed(){
		return speed;
	}

	public void radio(){
		System.out.print("Radio is playing music...");
	}

@Override
	public String getModel(){
		System.out.print("Hero Splender 125 DTS-Si");
		return "a";
	}

@Override
	public String getRegistrationNumber(){
		System.out.print("MP 09 XX 1234");
		return "a";
	}

@Override
	public String getOwner(){
		System.out.print("ABC PQR");
		return "a";
	}
}

class Honda extends Vehicle{

	int speed = 60;

	public int getSpeed(){
		return speed;
	}

	public void cdPlayer(){
		System.out.print("CD Player is playing music...");
	}

@Override
	public String getModel(){
		System.out.print("Honda Activa 6G");
		return "a";
	}

@Override
	public String getRegistrationNumber(){
		System.out.print("MP 09 XX 4321");
		return "a";
	}

@Override
	public String getOwner(){
		System.out.print("DEF GHI");
		return "a";
	}
}