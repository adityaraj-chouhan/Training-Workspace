import java.util.Scanner;
class Square{
	public static void main(String[] args){
		Scanner sc =new Scanner(System.in);
		
		String str= sc.nextLine();
		try{
			int a=Integer.parseInt(str);
			System.out.println(" "+ a*a);
		}
		catch(NumberFormatException e){
			System.out.println("not an integer");
		}
		 
	}
	}