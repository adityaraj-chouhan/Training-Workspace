import java.util.Scanner;



class InvalidUser extends RuntimeException
{
InvalidUser (String s)
{
super(s);
}
InvalidUser (String s1 , String s2)
{

}
}



class UserRegister{
void addRegister(String username , String userCountry)
{
try{
if(userCountry.equalsIgnoreCase("India"))
{
System.out.println("User register succesfully");

}
else
{
throw new InvalidUser("User is not from india");

}
}
catch(InvalidUser e){
e.printStackTrace();
System.exit(0);
}
}



public static void main(String[] args)
{
Scanner sc = new Scanner (System.in);
System.out.println("Enter name ");
String str= sc.nextLine();
System.out.println("Enter country ");

String country= sc.nextLine();

UserRegister ur= new UserRegister();
ur.addRegister(str, country);




}
}