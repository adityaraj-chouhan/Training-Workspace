import java.util.Scanner;
class Range extends RuntimeException
{
Range (String s)
{
super(s);
}
}
class NegativeInput extends RuntimeException
{
NegativeInput (String s)
{
super(s);
}
}
class Throw6
{
public static void main(String[] args)
{
Scanner sc = new Scanner (System.in);
System.out.println("Enter name of 1st student");
String str1 = sc.nextLine();
System.out.println("Enter name of 2nd student");
String str2 = sc.nextLine();
int a[]= new int[3];
int b[]= new int[3];
int avg1=0,avg2=0;
int s1=0,s2=0;
try{
System.out.println("Enter Marks of 1st student");
for(int i=0;i<3;i++)
{
int k =sc.nextInt();
if(k>=0 && k<=100){
a[i]=k;
s1+=a[i];
}
else if (k<0) throw new NegativeInput("Negative marks is not permited !!, program is terminated restart again to continue");
else throw new Range("Marks is out of range , program is terminated restart again to continue");

}

System.out.println("Enter Marks of 2nd student");




for(int i=0;i<3;i++)
{
int k =sc.nextInt();
if(k>=0 && k<=100){
b[i]=k;
s2+=b[i];
}
else if (k<0) throw new NegativeInput("Negative marks is not permited, program is terminated restart again to continue !!");
else throw new Range("Marks is out of range , program is terminated restart again to continue");

}

}
catch(NegativeInput e)
{
e.printStackTrace();
System.exit(0);
}
catch(Range e)
{
e.printStackTrace();
System.exit(0);
}
System.out.println("Normal Termination");
System.out.println("avgs of student 1 "+s1/3);
System.out.println("avgs of student 2 "+s2/3);

}
}