class ExceptionMessageFinally{
	public static void main (String[] args){
		try{
			int a=100,b=0,c=0;
			
			System.out.println(c);
			}
		finally{
			System.out.println("finally block");
		}
}		
}