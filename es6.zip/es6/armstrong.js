function show(msg)

{

  console.log(msg);

}

var pro= new Promise(function(myResolve,myReject)

{

  var str='race';

  let j = str.length -1;

    for( let i = 0 ; i < j/2 ;i++)

    {

      let x = str[i] ;

      let y = str[j-i];

      if( x != y)

      {

        myReject("String is not palindrome");

      }

    }

    myResolve("String is palindrome");

});

pro.then(function(value){show(value);},function(error){show(error);});