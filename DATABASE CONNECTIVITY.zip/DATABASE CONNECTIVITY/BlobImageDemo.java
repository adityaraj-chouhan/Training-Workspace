import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class BlobImageDemo {
	public static void main(String[] args) {
		try{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//create connection
			String url= "jdbc:mysql://localhost:3306/adityaraj";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			//String q= "insert into image(photo) values(?)";
			System.out.println("Connection established......");
			PreparedStatement ps=con.prepareStatement("insert into image(photo) values(?)");
			ps.setString(1,"sample image");
			InputStream in = new FileInputStream("D:\\notes\\1.PNG");
			ps.setBlob(1,in);
			ps.executeUpdate();
			System.out.println("inserted");
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}

