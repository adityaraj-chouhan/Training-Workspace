	import java.sql.*;
public class PreparedDemo {
	public static void main(String[] args) {
		try{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//create connection
			String url= "jdbc:mysql://localhost:3306/adityaraj";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			// creating query
			String q= "insert into employee(empID,name) values(?,?)";
			PreparedStatement ps=con.prepareStatement(q);
			// setting the values
			ps.setInt(1,2400);
			ps.setString(2, "yash tech");
			ps.executeUpdate();
			System.out.println("inserted");
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
