import javax.swing.*;
public class SwingDemo {
		SwingDemo(){
			JFrame f= new JFrame();
			JTextArea area=new JTextArea("Text area "); //text area
			area.setBounds(10,30, 200,200);
			f.add(area);
			f.setSize(300,300);
			f.setLayout(null);
			f.setVisible(true);
		}
		public void rado(){
			JFrame f;
			f=new JFrame();
			JRadioButton r1=new JRadioButton("Yash Tech");
			JRadioButton r2=new JRadioButton("Adityaraj");
			r1.setBounds(75,50,100,30);
			r2.setBounds(75,100,100,30);
			ButtonGroup bg=new ButtonGroup();

			f.setSize(300,300);
			f.setLayout(null);
			f.setVisible(true);
		}
		public static void main(String[] args) {
			SwingDemo tae = new SwingDemo();
			tae.rado();
			JFrame f=new JFrame(" Application"); 

			JButton b=new JButton("click");
			b.setBounds(100,700,80, 25);

	
			f.setVisible(true);
			JFrame p=new JFrame("Password Field Example"); 
			JPasswordField value = new JPasswordField();
			JLabel l1=new JLabel("Password:");
			l1.setBounds(20,100, 80,30);
			value.setBounds(100,100,100,30);
			p.add(value); f.add(l1);
			p.setSize(300,300);
			p.setLayout(null);
			p.setVisible(true);

		}
		}
	
	
