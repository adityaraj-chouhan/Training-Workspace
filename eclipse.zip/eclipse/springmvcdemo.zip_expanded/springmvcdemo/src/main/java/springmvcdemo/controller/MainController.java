package springmvcdemo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MainController {
//	@RequestMapping("/home")
//	public String home(Model model)
//	{
//		model.addAttribute("name","jay");//sending data to a jsp page from the controller
//		List<String> empList = new ArrayList<String>();
//		empList.add("Atul");
//		empList.add("Abhinav");//Model is only for single attribute to the view
//		empList.add("Prince");
//		empList.add("Gaurav");
//		model.addAttribute("list_c",empList);
//	return "index";
//}
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public ModelAndView listAction() {

		List<String> emp = new ArrayList<String>();
		emp.add("Atul");
		emp.add("Abhinav");
		emp.add("Prince");
		emp.add("Gaurav");

		ModelAndView mv = new ModelAndView();// linkage between bot model and view(extension to the model)

		mv.setViewName("index");
		mv.addObject("emp", emp);

		return mv;

	}

	@RequestMapping("/about")
	public String about(Model model) {

		return "about";
	}

	@RequestMapping("/request")
	public String request()
	{
		return  "request";
	}
	@RequestMapping(path = "/request", method = RequestMethod.POST)
	public String handlerequest(@RequestParam("email") String emailid) {
		System.out.println(emailid);

		return "success";
	}

}

