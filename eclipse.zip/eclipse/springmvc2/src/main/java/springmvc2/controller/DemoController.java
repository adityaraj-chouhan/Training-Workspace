package springmvc2.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DemoController {
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public ModelAndView listAction() {

		List<String> emp = new ArrayList<String>();
		emp.add("Atul");
		emp.add("Abhinav");
		emp.add("Prince");
		emp.add("Gaurav");

		ModelAndView mv = new ModelAndView();

		mv.setViewName("index");
		mv.addObject("emp", emp);

		return mv;

	}

}
