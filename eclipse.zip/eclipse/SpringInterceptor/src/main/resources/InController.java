package com.yash.springinterceptor;

import java.util.logging.Logger;



@Controller
@RequestMapping("/")
public class InController {
	private static final Logger logger = Logger.getLogger("InController");



	@RequestMapping(method = RequestMethod.GET)
	public String printStatus(ModelMap model) {
	logger.info("InController -> printStatus");
	model.addAttribute("status", "SUCCESS!");
	return "success";
	}

}
