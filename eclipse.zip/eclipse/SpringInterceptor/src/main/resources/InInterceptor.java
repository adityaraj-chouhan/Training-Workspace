package com.yash.springinterceptor;

public class InInterceptor implements HandlerInterceptor {
	private static final Logger logger = Logger.getLogger("InInterceptor");

	public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
	logger.info(" Pre handle ");
	if(httpServletRequest.getMethod().equals("GET"))
	return true;
	else
	return false;

}
