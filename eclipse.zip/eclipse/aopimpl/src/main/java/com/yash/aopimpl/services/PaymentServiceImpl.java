package com.yash.aopimpl.services;

public class PaymentServiceImpl implements PaymentService {




public void makePayment() {
// TODO Auto-generated method stub

System.out.println("Debit code");

//
//
System.out.println("Credit code");

}




}
