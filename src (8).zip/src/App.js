import Home from "./pages/home/Home";
import Login from "./pages/login/Login";
import Profile from "./pages/profile/Profile";
import Register from "./pages/register/Register";
import EditProfile from "./pages/editprofile/EditProfile";
import Imageprofile from './components/imageprofile/Imageprofile';

import Chats from "./pages/chats/chat";
// import ChatFeed from "./pages/chat/ChatFeed"
// import ChatFeed from "./components/ChatFeed"
import {BrowserRouter,Routes,Route} from "react-router-dom";

function App() {
  return(
<>
    
  <BrowserRouter>
  <Routes>
    <Route path="/" element={<Login/>}/>
    <Route path="/home" element={<Home/>}/>
    <Route path="/register" element={<Register/>}/>
    <Route path="/profile" element={<Profile/>}/>
    <Route path="/imageprofile" element={<Imageprofile/>}/>
    <Route path="/editprofile" element={<EditProfile/>}/>
    <Route path="/chats" element={<Chats/>}/>
    
  </Routes>
  
  </BrowserRouter>
  
  </>
  );
};

export default App;
