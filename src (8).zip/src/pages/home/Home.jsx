import Topbar from "../../components/topbar/Topbar";
import Sidebar from "../../components/sidebar/Sidebar";
import Feed from "../../components/feed/Feed";
import Rightbar from "../../components/rightbar/Rightbar";
import "./home.css"
import { getData } from "../../SessionMaintain";
import { useNavigate } from "react-router-dom";


export default function Home() {
  // const navigate=useNavigate();
  // if(
  //   getData()==="user"
  // )

  // {
  return (
    <>
      <Topbar />
      <div className="homeContainer">
        <Sidebar />
        <Feed/>
        {/* <Rightbar/> */}
      </div>
    </>
  );
}
// else{
//   navigate("/")
//   return{

//   }
// }
// }
