import "./editprofile.css";
import Topbar from "../../components/topbar/Topbar";
import React, { useState, navigate } from 'react'
import { useNavigate } from "react-router-dom"
import { getData } from "../../SessionMaintain";

export default function Editprofile() {

  
  
  const [name, setName] = useState("");
  const [empid, setEmpid] = useState("");
 
  const [city, setCity] = useState("");
  const [gender, setGender] = useState("");
  const [phone, setPhone] = useState("");
  const [about, setAbout] = useState("");
  const [designation, setDesignation] = useState("");
  const [dob, setDob] = useState("");
  const navigate = useNavigate();
  const handleClick = (event) => {
    const client = { empid, name, city, gender, phone, designation, dob, about,  };
    console.log(client);
    fetch("http://localhost:8080/user/editprofile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(client)
    }).then(res => res.json())
      .then((result) => {
        alert("your data is updated");
        navigate("/");

      })
  }
  // if(
  //   getData()==="user"
  // )

  // {

  return (
    <>
      <Topbar />
      {/* <form> */}
      <div className="editprofile">
        <div className="editprofileWrapper">

          <span className="loginDesc"></span>
          <div className="editprofileRight">
            <h1><center><b><u>EDIT PROFILE</u></b></center></h1><br /><br/>
            <div className="editprofileBox">
              <input type="number" placeholder="Enter your Employee ID" id="empid" name="empid" className="editprofileInput" required
                value={empid} onChange={(event) => {
                  setEmpid(event.target.value)
                }}
                 />
              <input placeholder="Enter your Name" id="name" name="name" className="editprofileInput"
                value={name} onChange={(event) => {
                  setName(event.target.value)
                }}
                type={"text"} required />

              <input placeholder="Enter your Contact Number" id="phone" name="phone" className="editprofileInput"
                value={phone} onChange={(event) => {
                  setPhone(event.target.value)
                }}
                type="number" required />
            

              <input placeholder="Gender" id="gender" name="gender" className="editprofileInput"
                value={gender} onChange={(event) => {
                  setGender(event.target.value)
                }}
                type={"gender"} required />
              <input placeholder="Enter your Designation" id="designation" name="designation" className="editprofileInput"
                value={designation} onChange={(event) => {
                  setDesignation(event.target.value)
                }}
                type={"text"} required />
              <input placeholder="Enter your base Location" id="city" name="city" className="editprofileInput"
                value={city} onChange={(event) => {
                  setCity(event.target.value)
                }}
                required />
              <input type="textarea" placeholder="About you" id="about" name="about" className="editprofileInput"
                value={about} onChange={(event) => {
                  setAbout(event.target.value)
                }} required />
              <input placeholder="DATE OF BIRTH" id="dob" name="dob" className="editprofileInput"
                value={dob} onChange={(event) => {
                  setDob(event.target.value)
                }}
                type={"date"} required /><br />


              <button onClick={handleClick}><b>Submit</b></button>
            </div>
          </div>
        </div>
      </div>
      {/* </form> */}
    </>
  );
}
// else{
//   navigate("/")
//   return{

//   }
// }
// }

