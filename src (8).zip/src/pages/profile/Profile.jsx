import "./profile.css";
import Topbar from "../../components/topbar/Topbar";
import Sidebar from "../../components/sidebar/Sidebar";
import Feed from "../../components/feed/Feed";
import Rightbar from "../../components/rightbar/Rightbar";
import { AddAPhoto } from "@material-ui/icons";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { useState,useEffect } from "react";
import { getData } from "../../SessionMaintain";

export default function Profile() {

  
  const [name, setName]=useState("");
  const[about, setAbout] = useState("");
  // const navigate=useNavigate();
//   if(localStorage.getItem("empid")!="null"){
// navigate("/");}
useEffect(() => {
setName(localStorage.getItem("name"));
setAbout(localStorage.getItem("about"));


})
// const navigate=useNavigate();
//   if(
//     getData()==="user"
//   )

//   {

  return (
    <>
      <Topbar />
      <div className="profile">
        <Sidebar />
        <div className="profileRight">
          <div className="profileRightTop">
            <div className="profileCover">
              <img
                className="profileCoverImg"
                src="dp.png"
                alt=""
              />



              <img
                className="profileUserImg"
                src="dp.png"
                alt=""
              />
              <div className="profileIcons">
          <div className="profileIconItem"><Link className="Link" to="/imageprofile"><AddAPhoto/></Link>
              </div>
              </div>



            </div>
            <div className="profileInfo">
                <h4 className="profileInfoName"></h4>
                <span className="profileInfoDesc"><b>{name}</b></span>
            </div>
            <div className="profileInfo">
                <h4 className="profileInfoName"></h4>
                <span className="profileInfoDesc"><b>{about}</b></span>
            </div>
          </div>
          <div className="profileRightBottom">
            <Feed />
            <Rightbar profile/>
          </div>
        </div>
      </div>
    </>
  );
}
// // else{
// //   navigate("/")
// //   return{

// //   }
// // }
// }
