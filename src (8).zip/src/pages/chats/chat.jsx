import React from 'react'
import './chats.css';
import Topbar from "../../components/topbar/Topbar";
import Nav from '../../components/chatting/nav/Nav';
import { getData } from "../../SessionMaintain";
import Chats from '../../components/chatting/chats/Chats';






export default function chat() {
 
  return (
    <>
    <Topbar />
    
    <Nav/>
    
    <Chats/>
    
    
  
   
  
    
    
    </>
  )

}