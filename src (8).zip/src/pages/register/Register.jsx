import "./register.css";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";

export default function Register() {
  // hooks for email pass opt
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [empid, setEmpId] = useState();

  //using regex done validation
  const validEmail = (e) => {
    let emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@(yash.com)+$/;
    setEmail(e.target.value)
    if (!emailPattern.test(e.target.value)) {
      console.log("please enter valid email");
      setEmailError("Please enter a valid email(@yash.com)");
    } else {
      console.log("success");
      setEmailError("");
    }
  }
  const validPassword = (e) => {
    let passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{7,15}$/;
    setPassword(e.target.value)
    if (!passwordPattern.test(e.target.value)) {
      console.log("please enter strong password");
      setPasswordError("please enter a valid password");
    } else {
      console.log("success");
      setPasswordError("");
    }
    const submitHandle = (e) => {
      e.preventDefault()
    }
  }

  //sending opt to email
  const navigate = useNavigate();
  const handleClick1 = (event) => {
    event.preventDefault()
    const client = { email }
    console.log(client);
    let api = "http://localhost:8080/getOtp/" + email;
    fetch(api, {
      method: "GET",

    }).then(res => res.text())
      .then((result) => {
        alert(result);
      });
  };
  const handleClick2 = (event) => {
    event.preventDefault()
    const client = { otp }
    console.log(client);
    let api = "http://localhost:8080/validateOtp/" + otp;
    fetch(api, {
      method: "GET",
    }).then(res => res.text())
      .then((result) => {
        if (result === "you can login") {
          const client = { email, password, empid }
          console.log(client);
          fetch(("http://localhost:8080/user/user_exist"), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(client)
          })
            .then(res => res.text())
            .then((result) => {
              if (result === "User not registered!") {
                fetch(("http://localhost:8080/user/register"), {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify(client)
                })
                  .then(res => res.text())
                  .then((result) => {
                    alert(result);
                    if (result === "User registered successfully!") {
                      navigate("/editprofile");
                    }
                  })
              }
              else {
                alert("user already exist please login");
                navigate("/");
              }
            })
        }
      });
  };





  return (
    <div className="login">
      <div className="loginWrapper">
        <div className="loginLeft">
          <center><h3 className="loginLogo"><span style={{ color: "red" }}>Y</span><span style={{ color: "yellow" }}>a</span>s<span style={{ color: "blue" }}>h</span><span color="white">T</span><span style={{ color: "yellow" }}>a</span><span style={{ color: "pink" }}>l</span><span style={{ color: "Green" }}>k</span><span style={{ color: "purple" }}>s</span></h3>
          <span className="loginDesc">
            Connect with your Colleague on Yash Talks
          </span></center>
        </div>
        <div className="loginRight">
          <div className="loginBox">
          <center><h2><u>REGISTRATION FORM</u></h2></center><br/>
            <input type="email" value={email} onChange={validEmail} placeholder="Enter your Email" className="loginInput" /><br />
            <span style={{ color: "red" }}>{emailError}</span>

            <input type="password" value={password} onChange={validPassword} placeholder="Create New Password" className="loginInput" /><br />
            <span style={{ color: "red" }}>{passwordError}</span>

            <input type="number" value={empid} onChange={(event) => {
              setEmpId(event.target.value)
            }} placeholder="Enter your EmployeeID" className="loginInput" /><br />
{/* opt button */}
            <button className="loginButton" onClick={handleClick1}>Send OTP</button><br />

            <input placeholder="Enter OPT" id="otp" name="otp" className="loginInput"
              value={otp} onChange={(event) => {
                setOtp(event.target.value)
              }} type={"text"} required /><br></br>
{/* validate button */}
            <button className="loginButton" onClick={handleClick2}>Validate and register</button><br />
            <button className="loginRegisterButton">
              <Link className="Link" to="/">Log into Account</Link>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

