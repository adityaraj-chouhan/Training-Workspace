import "./login.css";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
export default function Login() {

  //creating hooks for employeeid,password,for password validate(passwordError)
  const [empid, setEmpId] = useState();
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("")

  //for password validation
  const validPassword = (e) => {
    let passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{4,8}$/;
    setPassword(e.target.value)
    if (!passwordPattern.test(e.target.value)) {
      console.log("please enter strong password(Aa9 and any special symbol");
      setPasswordError("please enter a valid password");
    } else {
      console.log("success");
      setPasswordError("");
    }
     }


  //for sending the data to backend 
  const navigate = useNavigate();
  const handleClick = (event) => {
    const client = { empid, password }
    console.log(client);
    localStorage.setItem("empid", empid);
    fetch("http://localhost:8080/user/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(client)
    })
      .then(res => res.text())
      .then((result) => {
        alert(result);
        if (result === "User successfully logged in!") {
          navigate("/home");
        }
        else if (result === "Password is incorrect!") {
          alert("please type correct password")
        }
        else (
          alert("Enter Valid employee id ID and Password")
        )
      })
  }
  return (
    <div className="login">
      <div className="loginWrapper">
        <div className="loginLeft">
          <center><h3 className="loginLogo"><span style={{ color: "red" }}>Y</span><span style={{ color: "yellow" }}>a</span>s<span style={{ color: "blue" }}>h</span><span color="white">T</span><span style={{ color: "yellow" }}>a</span><span style={{ color: "pink" }}>l</span><span style={{ color: "Green" }}>k</span><span style={{ color: "purple" }}>s</span></h3>
          <span className="loginDesc">
            Connect with your Colleague on Yash Talks
          </span></center>
        </div>
        <div className="loginRight">
          <div className="loginBox"><br></br>
            <center><h2><u>LOGIN FORM</u></h2></center>
            {/* input field of employee id and password */}
            <input type="number" value={empid} onChange={(event) => {
              setEmpId(event.target.value)
            }} placeholder="Enter your Employee ID" className="loginInput" required />

            <input type="password" value={password} onChange={validPassword} placeholder="Enter your Password" className="loginInput" required />
            <span style={{ color: "red" }}>{passwordError}</span>


            <button className="loginButton" onClick={handleClick}>Login</button><br />
            <button className="loginRegisterButton">
              <Link className="Link" to="/register">Create a New Account</Link>
             
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
