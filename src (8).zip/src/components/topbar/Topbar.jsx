import "./topbar.css";
import { Link, useNavigate } from "react-router-dom";
import { Search, Chat, Notifications } from "@material-ui/icons";
import { setData } from "../../SessionMaintain";
import { useState } from "react";

export default function Topbar() {
  const navigate = useNavigate()
  const handleClick = () => {
    localStorage.removeItem("name");
    localStorage.removeItem("about");
    navigate("/")
  }
  const [search, setSearch] = useState("");
    const handleClick2 = () => {
    const client = { search }

    console.log(client);

    fetch("http://localhost:8080/user/search", {

      method: "GET",

      headers: { "Content-Type": "application/json" },

      body: JSON.stringify(client)

    })
      .then(res => res.text())

      .then((result) => {
        alert(result);
      }
      )
  }
  return (
    <div className="topbarContainer">

      <div className="topbarLeft">

        <h3><span className="logo"><span style={{ color: "red" }}>Y</span><span style={{ color: "yellow" }}>a</span>s<span style={{ color: "blue" }}>h</span><span color="white">T</span><span style={{ color: "yellow" }}>a</span><span style={{ color: "pink" }}>l</span><span style={{ color: "Green" }}>k</span><span style={{ color: "purple" }}>s</span></span></h3>
      </div>
      <div className="topbarCenter">
        <div className="searchbar">
        <Search value={search} onChange={(event)=>{
              setSearch(event.target.value)
            }} placeholder="eg.abc@yash.com" className="searchIcon" />
          
          <input
            placeholder="Search for friend"
            className="searchInput"
          /><button onClick={handleClick2} >Search</button>
        </div>
      </div>
      <div className="topbarRight">
        <div className="topbarLinks">
          <span className="topbarLink"></span>
          <span className="topbarLink"></span>
        </div>
        <div className="topbarIcons">
          <div className="topbarIconItem">
            <Link className="Link" to="/chats"> <Chat /></Link>
            <span className="topbarIconBadge">3</span>
          </div>
         

        </div>
        <span className="topbarLink"><Link className="Link" to="/home">Home</Link> </span>
        <Link to="/profile"><img src="dp.png" alt="" className="topbarImg" /></Link>
      </div>
      <button onClick={handleClick} className="topbarLink" >Logout</button>
    </div>
  );
}
