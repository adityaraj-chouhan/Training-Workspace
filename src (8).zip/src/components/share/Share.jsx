import "./share.css";
import { Link } from "react-router-dom";
import { PermMedia } from "@material-ui/icons"
import { useNavigate } from "react-router-dom";
import { useState } from "react";
export default function Share() {
const [newTweet,setContent]=useState("")

const handleSubmit=()=>{
var current = new Date();
var time = current.toLocaleTimeString();
var empid= localStorage.getItem("empid")
var date = current.toLocaleDateString();
var name=localStorage.getItem("name");
const client={newTweet,date,time,name,empid};
fetch(("http://localhost:8080/user/tweet"), {

  method: "POST",

  headers: { "Content-Type": "application/json" },

  body: JSON.stringify(client)
})
  .then(res => res.text())
  .then((result) => {
    alert(result);
  })
}
  return (
    <div className="share">
      <div className="shareWrapper">
        <div className="shareTop">
          <img className="shareProfileImg" src="dp.png" alt="" />
          <input
            placeholder="What's in your mind?"
            className="shareInput" 
            value={newTweet}
            onChange={(event) => {
              setContent(event.target.value)}}
          />
        </div>
        <hr className="shareHr" />
        <div className="shareBottom">
          <div className="shareOptions">
            <div className="shareOption">
              <PermMedia htmlColor="tomato" className="shareIcon" />
              <span className="shareOptionText">Photo  <input type="file" /></span>
            </div>
          </div>
          <button className="shareButton" onClick={handleSubmit}> Share</button>
        </div>
      </div>
    </div>
  );
}
