import React from "react";
import { useState, useEffect } from "react";
import "./rightbar.css";
import { Link } from "react-router-dom";
import { Users } from "../../dummyData";
import Online from "../online/Online";
export default function Rightbar() {
  const [user, setUser] = useState([])
  const empid = localStorage.getItem("empid");
  const client = { empid };
  useEffect(() => {

    fetch("http://localhost:8080/user/profile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(client)
    }).then(res => res.json())
      .then((result) => {
        setUser(result);
        user.map(names);
        function names(username) {
          localStorage.setItem("name", username.name)
          localStorage.setItem("about", username.about)
        }
      }
      )
  })
  return (
    <>
      {user.map(us => (
        <div>
          <h3 className="rightbarTitle"><center><b><u>Employee information</u></b></center></h3><br/>
          <div className="rightbarInfo">
            <div className="rightbarInfoItem">
              <span className="rightbarInfoKey">Name:</span>
              <span className="rightbarInfoValue">{us.name}</span>
            </div>

            <div className="rightbarInfoItem">
              <span className="rightbarInfoKey">Contact Number:</span>
              <span className="rightbarInfoValue">{us.phone}</span>
            </div>
            <div className="rightbarInfoItem">
              <span className="rightbarInfoKey">Date of Birth:</span>
              <span className="rightbarInfoValue">{us.dob}</span>
            </div>
            <div className="rightbarInfoItem">
              <span className="rightbarInfoKey">Gender:</span>
              <span className="rightbarInfoValue">{us.gender}</span>
            </div>
            <div className="rightbarInfoItem">
              <span className="rightbarInfoKey">Designation:</span>
              <span className="rightbarInfoValue">{us.designation}</span>
            </div>
            <div className="rightbarInfoItem">
              <span className="rightbarInfoKey">City:</span>
              <span className="rightbarInfoValue">{us.city}</span>
            </div>
            <div className="rightbarInfoItem">
              <span className="rightbarInfoKey">About Us:</span>
              <span className="rightbarInfoValue">{us.about}</span>
            </div>
            <span style={{ textAlign: "center" }}><button className="rightbarInfoKeybutton"><Link className="Link" to="/editprofile">Edit Details</Link></button></span><br />
          </div>
        </div>
      ))}
    </>
  );
}


