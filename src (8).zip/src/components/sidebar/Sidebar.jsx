import "./sidebar.css";

import { Users } from "../../dummyData";
import CloseFriend from "../closeFriend/CloseFriend";
import { useEffect,useState } from "react";

export default function Sidebar() {
  const [allUser,setAllUser]=useState([]);
  const[birthday,setBirthday]=useState([]);
  useEffect(() => {
    fetch("http://localhost:8080/user/viewUser")
        .then(res => res.json())
        .then((result) => {
            setAllUser(result);
        })
        // fetch("http://localhost:8080/user/birthday")
        // .then(res => res.json())
        // .then((result) => {
        //     setBirthday(result);
        //     console.log(result);
        // })
})
  return (
  
    <div className="sidebar">
      <div className="sidebarWrapper">
      <div className="birthdayContainer">
          <img className="birthdayImg" src="gift.png" alt="" />
          <span className="birthdayText">
          {/* {birthday.map((birth)=>alert(birth)
)} have a birhday today. */}
          </span>
        </div><br/><br/>
        <h2>Colleagues</h2>
        <hr className="sidebarHr" />
        <ul className="sidebarFriendList">
{allUser.map(user=>(<>
{user.name!=localStorage.getItem("name")?<div><img className="dpImg" src="dp.png"/>{user.name}</div>:<></>}</>
))}
        </ul>
      </div>
    </div>
  );
}
