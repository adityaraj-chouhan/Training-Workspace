import React, { Component } from "react";
import "./userProfile.css";

export default class UserProfile extends Component {
  toggleInfo = (e) => {
    e.target.parentNode.classList.toggle("open");
  };
  render() {
    return (
      <div className="main__userprofile">
        <div className="profile__card user__profile__image">
          <div className="profile__image">
            <img src="y.jpg" />
          </div>
          <h4>you</h4>
          <p>Associate Trainee</p>
        </div>
         <h3>YOU ARE YASH EMPLOYEE</h3>
         <br></br><br></br>
        <h4>Information</h4><br></br>
        <p>Emp:______</p>
        <p>Name:_____</p>
        <p>Degisnation:____</p>

        
        
      </div>
    );
  }
}