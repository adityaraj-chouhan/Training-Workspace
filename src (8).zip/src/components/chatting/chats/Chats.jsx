import React, { Component } from 'react';
import "./chats.css";
import ChatList from "../chatList/ChatList";
import ChatContent from "../chatContent/ChatContent";
import UserProfile from "../userProfile/UserProfile";
export default class Chats extends Component{
    render(){
        return <div className='main_chatbody'>
            
         <ChatList/>   
         <ChatContent/>
         <UserProfile/>
        </div>
        
    }
}
