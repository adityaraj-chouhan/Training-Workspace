
import Share from "../share/Share";
import "./feed.css";

import { Card } from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import { useState, useEffect } from "react";
import { Users } from "../../dummyData";
import { MoreVert } from "@material-ui/icons";

// export default function Post({ post }) {
//   const [like,setLike] = useState(post.like)
//   const [isLiked,setIsLiked] = useState(false)

//   const likeHandler =()=>{
//     setLike(isLiked ? like-1 : like+1)
//     setIsLiked(!isLiked)
//   }


// export const Posts = [
//   {
//     like: 32,
//   }]
export default function Feed() {
  // const [like,setLike] = useState(post.like)
  // const [isLiked,setIsLiked] = useState(false)

  // const likeHandler =()=>{
  //   setLike(isLiked ? like-1 : like+1)
  //   setIsLiked(!isLiked)
  // }



  const [tweets, setTweets] = useState([])
  const [id, setDeleteId] = useState()
  useEffect(() => {
    fetch("http://localhost:8080/user/viewAllTweet").then(res => res.json())
      .then((result) => {
        setTweets(result);
      }
      )
  })
  const handleDelete = () => {
    const cartDelete = { id }
    fetch("http://localhost:8080/user/deletetweet/" + id).then(res => res.text())
      .then((result) => {
        alert(result)
      });

  }


  return (
    <div className="feed">
      <div className="feedPost">
        <Share />
        {tweets.slice(0).reverse().map(tweet => (

          <div className='col-6 col-md-2 mt-5 mb-5'>
            <Card className='shadow-lg card'>

              <Card.Body>

                <Card.Text>
                  <div className="post">
                    <div className="postWrapper">
                      <div className="postTop">
                        <div className="postTopLeft">
                          <img
                            className="postProfileImg"
                            src="dp.png"
                            alt=""
                          />
                          <span className="postUsername">
                            {tweet.name}
                          </span>
                          <span className="postDate">
                            {tweet.date}
                          </span>
                          
                        </div>
                        <div className="postTopRight">
                          <span className="postTime">
                            {tweet.time}
                          </span>
                        </div>

                      </div>
                      <div className="postCenter">
                        <div className='col-4'>
                         <center> <b>{tweet.newTweet}</b></center>
                        </div>
                      </div>
                      <div className="postBottom">
                      {/* <div className="postBottomLeft">
            <img className="likeIcon" src="like.png" onClick={likeHandler} alt="" />
            <img className="likeIcon" src="heart.png" onClick={likeHandler} alt="" />
            <span className="postLikeCounter">{like} people like it</span>
          </div> */}
                      <div className="postBottomRight">
                          {
                  localStorage.getItem("empid") == tweet.empid ?
                    <><button classname="postButton" onClick={handleDelete} onMouseOver={(e) => setDeleteId(tweet.id)}>Delete</button></> : <></>
                }</div>

                          
                        </div>
                    </div></div>
                </Card.Text>


                
              </Card.Body>
            </Card>
          </div>


        ))}
       
      </div>
    </div>

  );
}
