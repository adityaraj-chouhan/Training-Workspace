package com.yash.socialmediaproject.service;


import java.util.List;

import com.yash.socialmediaproject.model.Tweet;

public interface TweetService {
	  public String saveTweet(Tweet tweet);
	  
	  public String deleteTweet(int id);
	  
	  public Tweet viewTweet(int id);
	  public List<Tweet> viewAllTweet ();

}
