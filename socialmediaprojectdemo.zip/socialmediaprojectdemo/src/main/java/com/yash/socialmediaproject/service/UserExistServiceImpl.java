package com.yash.socialmediaproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.socialmediaproject.model.User;
import com.yash.socialmediaproject.repository.UserRepository;

@Service
public class UserExistServiceImpl implements UserExistService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public List<User> userExist(User user) {

		List<User> list = userRepository.findByEmpid(user.getEmpid());
		return list;
	}

}
