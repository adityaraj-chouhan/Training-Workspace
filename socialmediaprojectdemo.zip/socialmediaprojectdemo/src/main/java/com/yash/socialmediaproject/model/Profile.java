package com.yash.socialmediaproject.model;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GeneratorType;

@Entity
@Table(name="profile_details")

public class Profile {

	public Profile() {
		
	}
	
	@Id
	
	@Column(name="empid")
	private long empid;
	@Column(name="name")
	private String name;
	@Column(name="about")
	private String about;

	@Column(name="city")
	private String city;
	@Column(name="gender")
	private String gender;
	@Column(name="phone")
	private String phone;
	@Column(name="designation")
	private String designation;
	@Column(name="dob")
	private String dob;
	
	public long getEmpid() {
		return empid;
	}
	public void setEmpid(long empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDob() {
		String[] newdobarray=dob.split("-");
		String newdob=newdobarray[2]+"-"+newdobarray[1]+"-"+newdobarray[0];
		return newdob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	
}
