package com.yash.socialmediaproject.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yash.socialmediaproject.repository.UserRepository;
import com.yash.socialmediaproject.model.Profile;
import com.yash.socialmediaproject.repository.ProfileRepository;


@Service
public class ProfileServiceImpl implements ProfileService{
	  
	    @Autowired
	    private ProfileRepository profileRepository;
	    
	    @Autowired
	    private UserRepository userRepository;

	
		@Override
		public List<Profile> viewProfile(Profile profile) {
			return profileRepository.findById(profile.getEmpid());
			
		}

		@Override
		public Profile editProfile(Profile profile) {
			// TODO Auto-generated method stub
			
			return profileRepository.save(profile);
		}
		
		
//		public Profile ps(Profile profile) {
//			List<Profile> lst=this.profileRepository.findAll();
//			String s=profile.getEmpid();
//			List pst=this.userRepository.getContent();
//			return pst;
//		}
		
}