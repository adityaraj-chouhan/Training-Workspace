package com.yash.socialmediaproject.service;

import com.yash.socialmediaproject.model.User;

public interface UserSearchService {
	public User searchUser(User user);

}
