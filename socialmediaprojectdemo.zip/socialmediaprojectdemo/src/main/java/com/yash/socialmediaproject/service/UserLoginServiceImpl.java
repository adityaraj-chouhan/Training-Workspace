package com.yash.socialmediaproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.socialmediaproject.model.Profile;
import com.yash.socialmediaproject.model.User;
import com.yash.socialmediaproject.repository.ProfileRepository;
import com.yash.socialmediaproject.repository.UserRepository;

@Service
public class UserLoginServiceImpl implements UserLoginService {
	
	@Autowired
	private UserRepository userRepository;
@Autowired
private ProfileRepository profileRepository;
	@Override
	public List<User> userLogin(User user) {

		List<User> list = userRepository.findByEmpid(user.getEmpid());
		
		String value=""+list;
		if(value.equals("[]"))
		{
			return list;
		}else
		{
			String password=user.getPassword();
			user=list.get(0);
			if(password.equals(user.getPassword()))
			{
			return list;
			}
			return null;
		}
	}

	@Override
	public List<Profile> viewAll() {
		// TODO Auto-generated method stub
		return profileRepository.findAll();
	}

	
}
