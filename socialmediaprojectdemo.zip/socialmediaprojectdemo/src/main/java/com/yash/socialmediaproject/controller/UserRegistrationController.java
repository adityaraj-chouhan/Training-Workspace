package com.yash.socialmediaproject.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins="http://localhost:3000")
public class UserRegistrationController {
	private String otp="-1";
	
	@Autowired
	private EmailSenderService emailService;
	  public void triggerMail(String sendTo,String otp)
	    {
	        emailService.sendSimpleEmail(sendTo, otp,"Register OTP");
	    }

	    @GetMapping("/getOtp/{email}")
	    public String getOtp(@PathVariable ("email") String email)
	    {
	        Random r=new Random();
	        int x=r.nextInt(1000,9999);
	        otp=String.valueOf(x);
	        triggerMail(email, otp);
	        return "Email is send";
	    }

	    @GetMapping("/validateOtp/{checkOtp}")
	    public String validateUser(@PathVariable ("checkOtp") String checkOtp)
	    {
	        if(checkOtp.equals(otp))
	        {
	            otp="-1";
	            return "you can login";
	        }
	        else
	        {
	            return "Invalid Otp";
	        }
	    }
	    

}
