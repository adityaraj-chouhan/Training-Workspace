package com.yash.socialmediaproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import com.yash.socialmediaproject.model.Profile;
import com.yash.socialmediaproject.repository.ProfileRepository;

@Service
public class ProfileDobServiceImpl implements ProfileDobService {
	@Autowired
	private ProfileRepository profileRepository;

	@EventListener(Profile.class)
	@Override
	public List<String> profileDob(Profile profile) {
		// TODO Auto-generated method stub
		
		  final String LD_PATTERN = "MM-dd";
		  final DateTimeFormatter LD_FORMATTER= DateTimeFormatter.ofPattern(LD_PATTERN);
		  String dateString = LD_FORMATTER.format(LocalDate.now());
		List<String> returnp = new ArrayList<>();
		for(Profile p:profileRepository.findAll())
		{
			String dbdob=p.getDob();
			String[] dbdobarr=dbdob.split("-");
			String dbdob2=dbdobarr[1]+"-"+dbdobarr[0];
			if(dbdob2.equals(dateString))
			{
				returnp.add(p.getName());
			}
		}	
		return returnp;
	}
}

