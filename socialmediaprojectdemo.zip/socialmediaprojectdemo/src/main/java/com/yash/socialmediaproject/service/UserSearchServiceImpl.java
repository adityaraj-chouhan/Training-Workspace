package com.yash.socialmediaproject.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.socialmediaproject.model.User;
import com.yash.socialmediaproject.repository.UserRepository;

@Service
public class UserSearchServiceImpl implements UserSearchService{
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User searchUser(User user) {
		Optional<User> opt = userRepository.findById(user.getId()); 
		User userobj  =opt.get();
		 return userobj;
	}

}
