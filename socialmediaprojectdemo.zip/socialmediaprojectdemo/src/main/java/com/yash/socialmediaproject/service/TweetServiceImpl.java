package com.yash.socialmediaproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.yash.socialmediaproject.model.Tweet;
import com.yash.socialmediaproject.repository.TweetRepository;

@Service
public class TweetServiceImpl implements TweetService {

	@Autowired
	private TweetRepository tweetRepository;

	@Override
	public String saveTweet(Tweet tweet) {

	tweetRepository.save(tweet);
		return "done";
	}
	
	public String deleteTweet(int id)
	{
		tweetRepository.deleteById(id);
		return "delete";
	}
	
	public Tweet viewTweet(int id)
	{
		
		return tweetRepository.findById(id).get();
		
	}

	@Override
	public List<Tweet> viewAllTweet() {
		// TODO Auto-generated method stub
		return tweetRepository.findAll();
	}


}
