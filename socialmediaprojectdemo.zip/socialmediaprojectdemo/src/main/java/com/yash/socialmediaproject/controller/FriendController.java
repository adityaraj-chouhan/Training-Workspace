package com.yash.socialmediaproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.socialmediaproject.model.Friend;
import com.yash.socialmediaproject.service.FriendService;

@RestController
@CrossOrigin()
@RequestMapping("/friend")
public class FriendController {
	
	@Autowired
	private FriendService FriendService;
	
	@PostMapping("/Friend")
	public String setFriend(@RequestBody Friend Friend)
	{
	FriendService.saveFriend(Friend);
		return "New Friend added!";
	}
	/*
	@GetMapping("/delete/{id}")
	public String deleteFriend(@PathVariable int id)
	{
		this.FriendService.deleteFriend(id);
	 return "Friend deleted";	
	}
	*/
	/*@GetMapping("/viewFriend/{id}")
	public Friend viewFriend(@PathVariable("id") int id)
	{
	 return FriendService.viewFriend(id);
	}
	*/
	 
	@GetMapping("/viewFriend")
    public List<Friend> getAllF()
    {
        return FriendService.getAllFriend();
    }

	


}
