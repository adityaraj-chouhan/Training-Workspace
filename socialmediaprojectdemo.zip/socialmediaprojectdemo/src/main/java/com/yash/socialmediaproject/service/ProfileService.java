package com.yash.socialmediaproject.service;


import java.util.List;

import com.yash.socialmediaproject.model.Profile;


public interface ProfileService {
	  
	  public List<Profile> viewProfile(Profile profile);
	  public Profile editProfile(Profile profile);


}