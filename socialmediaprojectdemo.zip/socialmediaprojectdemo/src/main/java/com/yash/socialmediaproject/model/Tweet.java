package com.yash.socialmediaproject.model;

import java.util.Date;

//import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tweet_details")
public class Tweet {
	public Tweet() {
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	  private int id;

    @Column
    private String newTweet;
    
    @Column
    private String name;
    
    @Column
    private String date;
    
    @Column
    private String time;
    
    @Column
    private long empid;

    public long getEmpid() {
		return empid;
	}

	public void setEmpid(long empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNewTweet() {
        return newTweet;
    }

    public void setNewTweet(String newTweet) {
        this.newTweet = newTweet;
    }

}
