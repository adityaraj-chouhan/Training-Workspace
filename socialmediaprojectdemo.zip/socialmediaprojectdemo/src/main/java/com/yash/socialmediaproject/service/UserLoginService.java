package com.yash.socialmediaproject.service;

import java.util.List;

import com.yash.socialmediaproject.model.Profile;
import com.yash.socialmediaproject.model.User;

public interface UserLoginService {
	public List<User> userLogin(User user);
	public List<Profile> viewAll();
}
