/*package com.yash.socialmediaproject.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "post")
public class PostEntity {
	
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String id;

	@Column(name="empId")
    private String empId;

	@Column(name="originalEmpId")
    private String originalEmpId;

	@Column(name="content")
    private String content;

	@Column(name="createdAt")
    private Instant createdAt;

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getOriginalEmpId() {
		return originalEmpId;
	}

	public void setOriginalEmpId(String originalEmpId) {
		this.originalEmpId = originalEmpId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}
}

//	public List<CommentEntity> getComment() {
//		return comment;
//	}
//
//	public void setComment(List<CommentEntity> comment) {
//		this.comment = comment;
//	}
//
//    List<CommentEntity> comment = new ArrayList<>();
//}
*/