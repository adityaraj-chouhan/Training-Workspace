package com.yash.socialmediaproject.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.socialmediaproject.model.Friend;
import com.yash.socialmediaproject.repository.FriendRepository;
import com.yash.socialmediaproject.repository.UserRepository;

@Service
public class FriendServiceImpl implements FriendService {
	@Autowired
	private FriendRepository friendRepository;

	@Autowired
	UserRepository userRepository;

	@Override
	public String saveFriend(Friend friend) {
		friendRepository.save(friend);
		return "Done";
	}
/*
	public String deleteFriend(int id) {
		friendRepository.deleteById(id);
		return "delete";
	}
	

	/*public Friend viewFriend(int id) {

		return friendRepository.findById(id).get();

	}*/
	
	public List<Friend>getAllFriend()
    {
        return friendRepository.findAll();
    }

}
