package com.yash.socialmediaproject.service;

import com.yash.socialmediaproject.model.User;

public interface UserRegisterService {
	public User registerUser(User user);
}