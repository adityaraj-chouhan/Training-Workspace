package com.yash.socialmediaproject.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.socialmediaproject.model.Profile;
import com.yash.socialmediaproject.repository.ProfileRepository;

@Service
public class ProfileSearchServiceImpl implements ProfileSearchService {
	
	@Autowired
	private ProfileRepository ProfileRepository;
	
	@Override
	public Profile searchProfile(Profile profile) {
		try {
//			Optional<Profile> opt = ProfileRepository.findById(profile.getEmpid()); 
//			Profile Profileobj  =opt.get();
			 return null;
		}
		catch(Exception e) {
			return null;
		}
		
	}

}
