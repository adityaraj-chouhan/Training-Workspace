package com.yash.socialmediaproject.service;

import java.util.List;

import com.yash.socialmediaproject.model.Friend;


public interface FriendService {
	 public String saveFriend(Friend friend);
	  
	 // public String deleteFriend(int id);
	  
	 // public Friend viewFriend(int id);
	  
	  public List<Friend> getAllFriend();
}
