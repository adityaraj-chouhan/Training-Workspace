/*package com.yash.socialmediaproject.controller;

import com.yash.socialmediaproject.model.IdObjectEntity;
import com.yash.socialmediaproject.model.PostEntity;
import com.yash.socialmediaproject.model.ResponseObjectService;
import com.yash.socialmediaproject.service.PostService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class PostController {
    @Autowired(required = true)
    private PostService postService;

    @PostMapping("/insertpost")
    public ResponseEntity<ResponseObjectService> insertPost(@RequestBody PostEntity inputPost) {
//    	System.out.println("Inside Insert post");
        return new ResponseEntity<ResponseObjectService>(postService.insertPost(inputPost), HttpStatus.OK);
    }
    
    @PostMapping("/myposts")
    public ResponseEntity<ResponseObjectService> findPostByUserId(@RequestBody IdObjectEntity inputUserId) {
        return new ResponseEntity<ResponseObjectService>(postService.findPostByUserId(inputUserId), HttpStatus.OK);
    }

     @PutMapping("/updatebycomment")
    public ResponseEntity<ResponseObjectService> updateByComment(@RequestBody PostEntity inputPost) {
        return new ResponseEntity<ResponseObjectService>(postService.updatePostByComment(inputPost), HttpStatus.OK);
    }
     
     @GetMapping("/deletepost/{id}")
 	public String deletePost(@PathVariable String id)
 	{
 		this.postService.deletePost(id);
 	 return "post deleted";	
 	}

   
}*/
