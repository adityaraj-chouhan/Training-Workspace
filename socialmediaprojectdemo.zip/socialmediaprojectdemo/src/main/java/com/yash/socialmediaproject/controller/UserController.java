package com.yash.socialmediaproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.socialmediaproject.model.Profile;
import com.yash.socialmediaproject.model.User;
import com.yash.socialmediaproject.service.UserExistService;
import com.yash.socialmediaproject.service.UserLoginService;
import com.yash.socialmediaproject.service.UserRegisterService;
import com.yash.socialmediaproject.service.UserSearchService;

@RestController
@CrossOrigin(origins="http://localhost:3000")
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserRegisterService userRegisterService;
	
	@Autowired
	private UserExistService userExistService;
	
	@Autowired
	private UserLoginService userLoginService;
	
	@Autowired
	private UserSearchService userSearchService;
	
	@PostMapping("/register")
	public String register(@RequestBody User user) {
		userRegisterService.registerUser(user);
		return "User registered successfully!";
	}
	
	@PostMapping("/user_exist")
	public String customerExist(@RequestBody User user) {
		List<User> list = userExistService.userExist(user);
		String value=""+list;
		if(value.equals("[]"))
		{
			return "User not registered!";
		}else
		{
			return "User already registered!";
		}
	}
	
	@PostMapping("/login")
	public String userLogin(@RequestBody User user) {
		List<User> list = userLoginService.userLogin(user);
		String value=""+list;
		//System.out.print("inside login");
		if(value.equals("[]"))
		{
			return "User not registered!";
		}else if(list==null)
		{
			return "Password is incorrect!";
		}else 
		{
			return "User successfully logged in!";
		}
	}
	@GetMapping("/viewUser")
	public List<Profile> viewAllUser()
	{
		return userLoginService.viewAll();
	}
	
	
}

