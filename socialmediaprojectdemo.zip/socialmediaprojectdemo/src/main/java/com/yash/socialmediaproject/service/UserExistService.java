package com.yash.socialmediaproject.service;

import java.util.List;

import com.yash.socialmediaproject.model.User;


public interface UserExistService {
	public List<User> userExist(User user);
}
