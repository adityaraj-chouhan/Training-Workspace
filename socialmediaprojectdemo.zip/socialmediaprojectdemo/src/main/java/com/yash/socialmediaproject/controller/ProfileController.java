package com.yash.socialmediaproject.controller;

import java.util.List;

import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.socialmediaproject.model.Profile;
import com.yash.socialmediaproject.service.ProfileDobService;
import com.yash.socialmediaproject.service.ProfileService;
import com.yash.socialmediaproject.service.ProfileSearchService;

@RestController
@CrossOrigin
@RequestMapping("/user")

public class ProfileController {

	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private ProfileDobService profileDobService;
	
	@Autowired
	private ProfileSearchService profileSearchService;
	
	@PostMapping("/profile")
	public List<Profile> getProfile(@RequestBody Profile profile)
	{
		
		return profileService.viewProfile(profile);
		//return "Successfully Updated Profile";
	}
	
	@PostMapping("/editprofile")
	public Profile setProfile(@RequestBody Profile profile) {
		
		return profileService.editProfile(profile);
	}
	
	@GetMapping("/birthday")
	public String profileDob1(@RequestBody Profile profile) {
		String s=profileDobService.profileDob(profile).get(0);
		return s;
		
		
	}
	
	@GetMapping("/search")
	public Profile profileSearch(@RequestBody Profile profile) {
		return profileSearchService.searchProfile(profile);
	}
	
	
}
