package com.yash.socialmediaproject.service;

import java.util.List;

import com.yash.socialmediaproject.model.Profile;

public interface ProfileDobService{
	public List<String> profileDob(Profile profile);
}
