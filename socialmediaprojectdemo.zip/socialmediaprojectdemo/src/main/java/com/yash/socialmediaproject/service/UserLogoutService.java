package com.yash.socialmediaproject.service;

import java.util.List;

import com.yash.socialmediaproject.model.User;

public interface UserLogoutService {
	public List<User> userLogout(User user);
}

