package com.yash.socialmediaproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.yash.socialmediaproject.model.Profile;

@Repository
public interface ProfileRepository extends CrudRepository<Profile, Long> {

	
	List<Profile> findById(long empid);
	List<Profile> findAll();
	

}
