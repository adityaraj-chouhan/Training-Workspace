package com.yash.socialmediaproject.service;

import com.yash.socialmediaproject.model.Profile;

public interface ProfileSearchService {
	public Profile searchProfile(Profile profile);

}
