package com.yash.socialmediaproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.yash.socialmediaproject.model.Tweet;
import com.yash.socialmediaproject.service.TweetService;

@RestController
@CrossOrigin
@RequestMapping("/user")
public class TweetController {
	@Autowired
	private TweetService tweetService;
	
	@PostMapping("/tweet")
	public String setTweet(@RequestBody Tweet tweet)
	{
		tweetService.saveTweet(tweet);
		return "New tweet added!";
	}
	
	@GetMapping("/deletetweet/{id}")
	public String deleteTweet(@PathVariable int id)
	{
		this.tweetService.deleteTweet(id);
	 return "tweet deleted";	
	}
	
	@GetMapping("/viewtweet/{id}")
	public Tweet viewTweet(@PathVariable("id") int id)
	{
	 return tweetService.viewTweet(id);
	}
	@GetMapping("/viewAllTweet")
	public List<Tweet> viewAllTweet(){
		return tweetService.viewAllTweet();
	}
	 
	
}

