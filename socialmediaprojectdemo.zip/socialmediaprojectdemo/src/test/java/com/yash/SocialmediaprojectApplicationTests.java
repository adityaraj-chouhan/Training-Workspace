package com.yash;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.yash.socialmediaproject.model.User;
import com.yash.socialmediaproject.repository.UserRepository;

@SpringBootTest
class SocialmediaprojectApplicationTests {
	User user = new User();

    @Autowired
    UserRepository userrepository;

  @Test
  public void loginTestCase()
  {

      List<User> list = userrepository.findByEmail("pranit.gire@yash.com");
      assertThat(list).size().isGreaterThan(0);
  }


  @Test
  public void saveUserTest() {

        user.setId(1);
      user.setEmail("rajkuwar.chaudhari@yash.com");
      user.setPassword("Yash@123");

      userrepository.save(user);
  }

}
}
