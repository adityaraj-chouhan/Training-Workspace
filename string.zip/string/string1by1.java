class string1by1
{
 public static void main(String []args)
    {
	String s1 ="yaSh";
     String s2= "tech";
	 
	 String[] a1=s1.split("");
	 String[] a2=s2.split("");
	 
	 for(int i=0;i<=s1.toCharArray().length-1 ;i++)
	 {
		 System.out.print(a1[i]);	
		for(String a : a2)
		{
		 System.out.print(a2[i]);	
		 break;
		}
	 }
	 //System.out.print(s1,s2);
	 //}
	 
	 
	
	
	 
	 
	 }
	 
	 }
	 