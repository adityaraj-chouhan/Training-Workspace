import java.util.Scanner;

class stringwithout1st
{
 public static void main(String []args)
    {
		Scanner input = new Scanner(System.in);
		System.out.println("enter string ");
		String s = input.nextLine();
	//String s ="yaSh technologies";	
	
	System.out.println(s.substring(1,s.length() -1));
	input.close();
	}
	}
	