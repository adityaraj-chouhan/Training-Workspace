class stringpalindrome
{
 public static void main(String []args)
    {
	
	String b="" ;
	
	String a ="yaSh technologies";
	int n=a.length();
	for(int i=n-1; i>=0;i--)
	 {
	 b=b+a.charAt(i);
	 }
	 if(a.equalsIgnoreCase(b))
	 {
	  System.out.println(" pallindrome" );
	  }
	  else
	 {
	  System.out.println(" not pallindrome" );
	  }
	  }
	  }
	  