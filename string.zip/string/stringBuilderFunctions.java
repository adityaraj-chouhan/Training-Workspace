class stringBuilderFunctions
{
 public static void main(String []args)
    {
	
	StringBuilder s=new StringBuilder( "yaSh technologie");
	StringBuilder s1 = new StringBuilder("yash technologies");
	System.out.println(s);
	//System.out.println(s.trim());
	//System.out.println(s.equals(s1));
	//System.out.println(s.equalsIgnoreCase(s1));
	//System.out.println(s.compareTo(s1));
	//System.out.println(s.compareToIgnoreCase(s1));
	System.out.println(s.substring(0,6));
	//System.out.println(s.isEmpty());
	}
	}