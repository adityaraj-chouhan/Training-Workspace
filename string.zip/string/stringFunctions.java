class stringFunctions
{
 public static void main(String []args)
    {
	
	String s="yaSh technologie";
	String s1="yash technologies";
	//System.out.println(s);
	//System.out.println(s.trim());
	//System.out.println(s.equals(s1));
	//System.out.println(s.equalsIgnoreCase(s1));
	//System.out.println(s.compareTo(s1));
	//System.out.println(s.compareToIgnoreCase(s1));
	//System.out.println(s.substring(0,6));
	System.out.println(s.isEmpty());
	}
	}
	