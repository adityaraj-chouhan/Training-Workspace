import java.io.Console;
class ConsoleDemo
{
public static void main(String []args)
    {
	String str;
	char ch[];
	Console ob = System.console();
	System.out.print("enter user name");
	str= ob.readLine();
	System.out.print("enter password");
	ch=ob.readPassword();
	String a=String.valueOf(ch);
	System.out.println("username" + str +"password" + ch);
	System.out.println("actual password" + a);
	
}
}
