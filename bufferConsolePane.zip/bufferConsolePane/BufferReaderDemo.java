import java.io.BufferedReader;
import java.io.InputStreamReader;
class BufferReaderDemo
{
public static void main(String []args) throws Exception 
    {
	String str;
	char ch[];
	InputStreamReader i = new InputStreamReader(System.in);
	BufferedReader b = new BufferedReader(i);
	System.out.print("enter user name");
	str= b.readLine();

	
	}
	}