import javax.swing.*;
public class JOptionPaneDemo
{
JFrame f;
 void jOptionPaneDemo()
{
f=new JFrame();
JOptionPane.showMessageDialog(f,"aditya");
}
public static void main(String []args)
    {
	new JOptionPaneDemo();
	}
	}
	
	