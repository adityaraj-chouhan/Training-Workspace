class calc
{
   public static void main(String[] args)
   {
	   double n1, n2;
	   char operator ;
	   n1 =Double.parseDouble(args[0]);
       n2 =Double.parseDouble(args[1]);
	  
	  operator =args[2].charAt(0);
	  double output;
	  switch(operator)
	  {
		  case '+':
		  output = n1+n2;
		  break;
		  case '-':
		  output = n1-n2;
		  break;
		  case '*':
		  output = n1*n2;
		  break;
		  case '/':
		  output = n1/n2;
		  break;
		  default:System.out.println("wrong operator");
		  return;
	  }
	  System.out.println(" " + output );
	  
	  
	  
   } 
}	