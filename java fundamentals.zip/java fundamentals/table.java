class table
{
   public static void main(String[] args)
   {
     int a=Integer.parseInt(args[0]);
	 int i;
	 int num;
	 for(i=1;i<=10;i++)
	 {
	  
	 System.out.println("a=" + a*i);
	 }
	 
   } 
}
