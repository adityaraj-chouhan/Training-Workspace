class armstrong
{
   public static void main(String[] args)
   { int original, rem ,result=0;
     int a=Integer.parseInt(args[0]);
	 original= a;
	 while (original !=0)
	 {
      rem = original %10;
	  result= result + rem*rem*rem ;
	  original/=10;
	  
	}
	if(result==a)
		{
	    System.out.println("armstrong");
		}
		else
		{
		System.out.println("not armstrong");
}		}

}	
	
	