class swap
{
   public static void main(String[] args)
   { int temp;
     int a=Integer.parseInt(args[0]);
	 int b=Integer.parseInt(args[1]);
	 temp= a;
	 a=b;
	 b=temp;
	
	 System.out.println("a="+ a);
	  System.out.println("b=" +b);
   } 
}	