class pallindrome
{
 public static void main(String []args )
   {
	   int r;
	   int sum=0;
	   int temp;
	    int n=Integer.parseInt(args[0]);
		temp =n;
		while(n>0)
		  {
			r=n%10;
			sum =(sum*10)+r;
			n=n/10;
		  }
		if(temp==sum)
		{
	    System.out.println("pallindrome");
		}
		else
		{
		System.out.println("not pallindrome");
}}		}
