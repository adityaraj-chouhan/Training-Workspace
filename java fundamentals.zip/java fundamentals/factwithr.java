class factwithr
{	
    static int factorial(int n)
	if (n==0)
		return 1;
	else
		return n*fact(n-1);
	
   public static void main(String[] args)
   {
     int n=Integer.parseInt(args[0]);
	 
	 int factorial;
	 if (n>0)
	 {
		 factorial =fact(n);
		 System.out.println (" " + factorial);
		 
	 }
    else 
	{
		System.out.println (" number should be positive ");
	}
	
}}
	
	
	