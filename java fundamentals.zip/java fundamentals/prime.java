class prime
{
   public static void main(String[] args)
   { int i ,m=0,flag=0;
     int a=Integer.parseInt(args[0]);
	 m=a/2;
	 if(a==0 || a==1)
	 {
	 System.out.println("not prime");
	 }
	 else
	 {
	 
	 for (i=2;i<=m;i++)
	 {
	 if (a%i==0)
	 {
	 System.out.println("not prime");
	 
	 flag=1;
	 break;
	 }
	 }
	 if (flag==0)
     	 
	  {
	   System.out.println("prime");
	  }
	 }
   } 
}	