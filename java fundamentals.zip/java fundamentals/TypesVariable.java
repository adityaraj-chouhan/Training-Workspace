class TypesVariable
{ 
   int a=20;
   static int b=30;
   void add()
   {
     int c;
     c=a+b;
	 System.out.println(c);
   }
	
    public static void main (String [] args)
    {
      TypesVariable a=new TypesVariable();
	  a.add();
    }
}