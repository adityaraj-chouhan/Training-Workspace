import java.sql.*;
class FirstJdbcDemo
{
	public static void main(String[] args){
			try{
				//load the driver
				Class.forName("com.mysql.jdbc.Driver");
				//create connecion
				String url= "jdbc:mysql://localhost:3306/adityaraj";
				String user="root";
				String pass="root";
				Connection con=DriverManager.getConnection(url,user,pass);
				if(con!=null){
					System.out.println("connection is created sucessfully");
				}
				else{
					System.out.println("connection is not created");
				}
				// step 3 create query
				String q= "select * from employee";
				Statement st =con.createStatement();
				ResultSet set= st.executeQuery(q);
				
				//step 4 process the data
				while(set.next())
				{
					int id=set.getInt("empID");
					String name=set.getString("name");
					System.out.println("id"+id);
					System.out.println("name"+name);
					
				}
				//step4 connection close
				con.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
	}
}
