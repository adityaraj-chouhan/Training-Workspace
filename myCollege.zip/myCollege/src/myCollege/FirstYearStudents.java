package myCollege;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class FirstYearStudents extends Students {
	Boolean feesPaid;
	public FirstYearStudents(String name, int attendance, int enrollment, int result, Boolean feesPaid){	 
		super (name, attendance , enrollment, result);
		this.feesPaid=feesPaid;
		}
	@Override
	public void display(){
		System.out.println("NAME="+name+" " + " ATTENDANCE="+attendance+"%  " + " ENROLLMENT="+enrollment+" RESULT="+ result+"  FEES PAID="+ feesPaid);
		if(feesPaid==true && attendance>=75){
			System.out.println("is eligible to sit in exam");
		}
		else{
			System.out.println("not eligible to sit in exam");
		}
	}
	public void firstYearDatabase(){
		try{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//create connection
			String url= "jdbc:mysql://localhost:3306/mycollege";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			// creating query
			String q= "insert into FirstYearStudents values(?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(q);
			// setting the values

			Scanner input = new Scanner(System.in);
			System.out.println("name=");
			String name = input.nextLine();
			System.out.println("attendance=");
			int attendence = input.nextInt();
			System.out.println("enrollment=");
			int enrollment = input.nextInt();
			System.out.println("result=");
			int result = input.nextInt();
			//System.out.println("fees paid=");
			//String feespaid = input.nextLine();
			input.close();
			
			
			ps.setString(1, name);
			ps.setInt(2,attendance);
			ps.setInt(3,enrollment);
			ps.setInt(4,result);
			//ps.setString(5, feespaid);
			
			ps.executeUpdate();
			System.out.println("inserted");
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
