package myCollege;

public interface CollegeData {
	public void getCollegeData();
}
