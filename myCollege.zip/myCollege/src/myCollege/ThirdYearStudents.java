package myCollege;

public class ThirdYearStudents extends Students{
	boolean feesPaid;
	public ThirdYearStudents(String name ,int attendance,int enrollment, int result ,boolean feesPaid){ 
		super (name, attendance , enrollment,result);
		this.feesPaid=feesPaid;
	}
	
	
	@Override
	public void display(){
		System.out.println("NAME="+name+" " + " ATTENDANCE="+attendance+"%  " + " ENROLLMENT="+enrollment+" RESULT="+ result+"  FEES PAID="+ feesPaid);
		
		if(feesPaid==true && attendance>=75){
			System.out.println("is eligible to sit in exam");
		}
		else{
			System.out.println("not eligible to sit in exam");
		}
	}
	

}
