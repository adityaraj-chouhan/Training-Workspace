package myCollege;

public class Professors extends Faculties {
int salary ;
	
	public Professors(String name ,int id , String department, int salary){
		super(name,id,department);
		this.salary=salary;
	}
	@Override
	public void display(){
		System.out.println( "NAME="+name+ "  "+ "  ID=" +id+ " "+"  DEPARTMENT="+department + " "+"  SALARY="+salary);
	}
	

}
