package myCollege;
import java.awt.image.ImagingOpException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.*;

class Main implements CollegeData{
	static ArrayList<FirstYearStudents> arr=new ArrayList<>();
	static ArrayList<SecondYearStudents> arr2=new ArrayList<>();
	static ArrayList<ThirdYearStudents> arr3=new ArrayList<>();
	static ArrayList<FourthYearStudents> arr4=new ArrayList<>();
	static ArrayList<Directors> arr5=new ArrayList<>();
	static ArrayList<HeadOfDepartment> arr6=new ArrayList<>();
	static ArrayList<Professors> arr7=new ArrayList<>();
	static String userInput="";
	
	public static void main(String[] args){
		//calling interface method.
		Main mainObj = new Main();
		mainObj.getCollegeData();
		
		
		
		showMenu(); //Showing menu
		try {
			userInput = getUserInput();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		} //getting user input
		
		System.out.println("\n");
		
		
			displayData(userInput);
		 //displaying data
	}

	
	private static void displayData(String s)  {
		switch(s){
		case "0":{
			System.out.print("You have exited the program, thank you!");
		}
		break;
		case "1":{
			try {
				for(FirstYearStudents i:arr){
					i.display();
					
				}	
			}catch (Exception e) {
				System.out.println(e);
			}finally {
				System.out.println("Compilation Successfull");
			}
			
		}
		break;
		case "2": {
			try {
				for(SecondYearStudents i:arr2){
					i.display();
				}	
			}catch (Exception e) {
				System.out.println(e);
			}finally {
				System.out.println("Compilation Successfull");
			}
		}
		break;
		case "3":{
			try {
				for(ThirdYearStudents i:arr3){
					i.display();
				}	
			}catch (Exception e) {
				System.out.println(e);
			}finally {
				System.out.println("Compilation Successfull");
			}
		}	
		break;
		case "4": {
			try {
				for(FourthYearStudents i:arr4){
					i.display();
				}	
			}catch (Exception e) {
				System.out.println(e);
			}finally {
				System.out.println("Compilation Successfull");
			}
		}	
		break;
		case "5":{
			try {
				for(Directors i:arr5){
					i.display();
					
				}
				
			}catch (Exception e) {
				System.out.println(e);
			}finally {
				System.out.println("Compilation Successfull");
			}
		}	
		break;
		case "6":{
			try {
				for(HeadOfDepartment i:arr6){
					i.display();
				}	
			}catch (Exception e) {
				System.out.println(e);
			}finally {
				System.out.println("Compilation Successfull");
			}
		}	
		break;
	    case "7":{
	    	try {
	    		for(Professors i:arr7){
					i.display();
				}	
			}catch (Exception e) {
				System.out.println(e);
			}finally {
				System.out.println("Compilation Successfull");
			}
		}	
		break;
	    case "8":{
	    	try {
	    		for(FirstYearStudents j:arr) {
	    			j.firstYearDatabase();
				}
	    	}
			catch (Exception e) {
				System.out.println(e);
			}
		}	
		break;
		}
	}
	
	private static void showMenu() {
		System.out.print("Please choose from menu:" 
				+ "\n 1 --> first year students."
				+ "\n 2 --> second year students."
				+ "\n 3 --> third year students."
				+ "\n 4 --> fourth year students."
				+"\n -------------------------"
				+"\n 5 --> View Directors."
				+"\n 6 --> View HeadOfDepartment."
				+"\n 7 --> View Professor."
				+"\n 0 --> Exit."
				+"\n 8 -->enter new first year student."
				);
	}

	@Override
	public void getCollegeData() {
		//students
		FirstYearStudents fy1  = new FirstYearStudents("Ritik Dave",83 ,30891 ,89,true);
		FirstYearStudents fy2  = new FirstYearStudents("Sahil Gupta",86 ,30891 ,87,true);
		arr.add(fy1);
		arr.add(fy2);
		
		SecondYearStudents sy = new SecondYearStudents("Pranav Goswami",68,30892,82,false);
		arr2.add(sy);
		
		ThirdYearStudents ty = new ThirdYearStudents("Chaitanya Mohta",72 ,30893 ,63,true);
		arr3.add(ty);
		
		FourthYearStudents foy = new FourthYearStudents("Vedant Patil",91 ,30894 ,77,true);
		arr4.add(foy);
		
		//faculties
		Directors d= new Directors("Mr Vishal Bhatia",18020,"Computer Science",100000);
		arr5.add(d);
		
		HeadOfDepartment h1= new HeadOfDepartment("Ms Renuka Sharma",19250,"Computer Science",80000);
		HeadOfDepartment h2= new HeadOfDepartment("Mr Bharat Sharma",19250,"Civil Engineering",70000);
		arr6.add(h1);
		arr6.add(h2);
		
		Professors p1= new Professors("Mr Shivendra Singh",19930,"Computer Science",50000);
		Professors p2= new Professors("Mr Aryan Singh",19930,"Civil Engineering",50000);
		arr7.add(p1);
		arr7.add(p2);
	}

	private static String getUserInput() throws IOException {

		/*Scanner input = new Scanner(System.in);
		String s = input.nextLine();
		input.close();
		return s;
		*/
		String s;
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader b = new BufferedReader(in);
		s=b.readLine();
	return s;
	
	}
	

}

