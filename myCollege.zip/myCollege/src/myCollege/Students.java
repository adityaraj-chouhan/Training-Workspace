package myCollege;

abstract public class Students {
	String name;
	int attendance;	
	int enrollment;
	int result;
	
	Students(String name ,int attendance ,int enrollment, int result) {
		this.name=name;
		this.attendance=attendance;
		this.enrollment=enrollment;
		this.result=result;
	}
	
	public abstract void display();
}
