import java.util.Vector;

import java.util.Iterator;

public class VectorDemo {
	public static void main(String[] args) {
		Vector<String> a= new Vector<String>();
		a.add("one");
		a.add("two");
		a.add("three");
		a.add("four");
		System.out.println(a);
		Iterator i=a.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		
		}
		for(String j:a) {
			System.out.println(" "+j);
		}
	}


}
