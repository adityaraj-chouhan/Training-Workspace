import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListMonths {
	public static void main(String[] args) {
		ArrayList<String> a= new ArrayList<String>();
		a.add("jan");
		a.add("Feb");
		a.add("march");
		a.add("april");
		a.add("may");
		a.add("june");
		a.add("july");
		a.add("aug"); 
		a.add("sept");
		a.add("oct");
		a.add("nov");
		a.add("dec");
		//System.out.println(a);
		Iterator i=a.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		
		}
		for(String j:a) {
			System.out.println(" "+j);
		}
	}


}
