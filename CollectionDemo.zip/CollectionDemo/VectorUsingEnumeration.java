import java.util.Vector;
import java.util.Enumeration;
public class VectorUsingEnumeration {
	public static void main(String[] args) {
		Vector<String> a= new Vector<String>();
		a.add("jan");
		a.add("Feb");
		a.add("march");
		a.add("april");
		a.add("may");
		a.add("june");
		a.add("july");
		a.add("aug"); 
		a.add("sept");
		a.add("oct");
		a.add("nov");
		a.add("dec");
		System.out.println(a);
		Enumeration<String> e= a.elements();
		while (e.hasMoreElements())
		{
			System.out.println(e.nextElement());
		}
		
		
		
	}
}
