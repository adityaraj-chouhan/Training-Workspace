import java.util.HashSet;
import java.util.Iterator;

public class HashSetEmployee {
	public static void main(String[] args) {
		HashSet<String> a= new HashSet<String>();
		a.add("adi");
		a.add("shivam");
		a.add("ritik");
		a.add("pranav");
		//System.out.println(a);
		Iterator i=a.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		
		}
		for(String j:a) {
			System.out.println(" "+j);
		}
	}

}
