import java.util.Vector;
import java.util.Iterator;
public class EmployeeVector {
	private int id;
	private String name;
	
	public EmployeeVector(int id ,String name){
		super();
		this.id=id;
		this.name=name;
		}
	public int getId() {
		return id;
	
	}
	@Override
	public String toString() {
		return "Employee id=" + id +" name="+ name;
	}



	public static void main(String[] args) {
		Vector<EmployeeVector> a= new Vector<EmployeeVector>();
		a.add(new EmployeeVector( 102,"adi"));
		a.add(new EmployeeVector( 108,"raj"));
		
		Iterator it= a.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
}

