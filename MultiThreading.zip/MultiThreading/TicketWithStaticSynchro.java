class BookTicket{
	static int totalseats=12;
	static void bookseat(int seats){
		
		if(totalseats>=seats) {
			System.out.println("book successful");
			totalseats=totalseats-seats;
			System.out.println("remaining seats"+totalseats);
		}
		else {
			System.out.println("seats are not available"+ totalseats);
		}
	}
}
class Thread1 extends Thread{
	static BookTicket b;
	int seats;
	Thread1(BookTicket b,int seats){
		this.b=b;
		this.seats=seats;
	}
	public void run() {
		b.bookseat(seats);
		
	}
}
class Thread2 extends Thread{
	static BookTicket b1;
	int seats;
	Thread2(BookTicket b,int seats){
		this.b1=b1;
		this.seats=seats;
	}
	public void run() {
		b1.bookseat(seats);
		
	}
}

public class TicketWithStaticSynchro extends Thread {

	public static void main(String[] args) {
		BookTicket b=new BookTicket();
		BookTicket b1=new BookTicket();
		Thread1 t1=new Thread1(b,8);
		t1.start();
		Thread2 t2=new Thread2(b,3);
		t2.start();
		Thread1 t3=new Thread1(b1,3);
		t3.start();
		Thread2 t4=new Thread2(b1,4);
		t4.start();
		
	
	}

}



