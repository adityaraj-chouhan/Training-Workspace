
public class ThreadDemoInterface implements Runnable {
	public void run() {
		System.out.println("thread started");
	}
	public static void main(String[] args) {
		ThreadDemo t =new ThreadDemo();
		Thread t1= new Thread(t);

		t.start();
		
	}

}
