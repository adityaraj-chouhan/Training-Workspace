//Single task from Single Thread
public class ThreadDemoSingleSingle extends Thread
{public void run() {
	System.out.println("thread started");
}
public static void main(String[] args) {
	ThreadDemo t =new ThreadDemo();
	t.start();
	
}

}
