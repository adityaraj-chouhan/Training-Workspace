/*class BookTicket{
	int totalseats=12;
	void bookseat(int seats){
		synchronized(this) {
		if(totalseats>=seats) {
			System.out.println("book successful");
			totalseats=totalseats-seats;
			System.out.println("remaining seats"+totalseats);
		}
		else {
			System.out.println("seats are not available"+ totalseats);
		}
	}}
}*/
public class TicketWithSynchroBlock extends Thread {
	static BookTicket b;
	int seats;
	public void run() {
		b.bookseat(seats);
		
	}
	public static void main(String[] args) {
		b=new BookTicket();
		TicketWithSynchroBlock p1=new TicketWithSynchroBlock();
		p1.seats=8;
		p1.start();
		TicketWithSynchroBlock p2=new TicketWithSynchroBlock();
		p2.seats=10;
		p2.start();
		
		
	}

}



