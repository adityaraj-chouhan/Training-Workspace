
public class ThreadDaemonDemo extends Thread {
	public void run() {
		
		//System.out.println("in run method");
		
		if(Thread.currentThread().isDaemon()){
			System.out.println("in daemon thread");
		}
		else {
			System.out.println("in non daemon thread");
		}
	}
		
	public static void main(String[] args) {
		System.out.println("main thread");
		ThreadDaemonDemo t =new ThreadDaemonDemo();
		t.setDaemon(true);
		t.start();
		
	}

}
