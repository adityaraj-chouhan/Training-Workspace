class sumofarray 
{
   public static void main(String[] args)
   {
     int[] a= new int[] {1,2,3,4,5};
      int sum=0;
	  int length= a.length;
  	  for(int i=0;i<a.length;i++)
	  {
	  sum= sum+a[i];
	  }
	  System.out.println(" "+ sum);
	  double avg= sum/length;
	   System.out.println(" "+ avg);
	  
	  }
}
	  