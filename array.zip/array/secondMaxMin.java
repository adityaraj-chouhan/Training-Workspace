class secondMaxMin
{
   public static void main(String[] args)
   {
     int[] a= new int[] {1,2,3,4,5};
      int temp=0;
	  int min = a[0];
	  int length= a.length;
  	  for(int i=0;i<a.length;i++)
	   {
	   for(int j=i+1; j<a.length; j++)
	     {
		 if (a[i]>a[j])
		   {
		   temp= a[i];
		   a[i]=a[j];
		   a[j]=temp;
		   }
		   
		   }
		  }
		   System.out.println(" "+ a[length-2]);
		    System.out.println(" "+ a[1]); // as array is sorted ans index start from 0
}
}		  