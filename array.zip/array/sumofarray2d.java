class sumofarray2d 
{
   public static void main(String[] args)
   {
     int[][] a= new int[][] {{1,2,3,4,5},{9,8,7,6,5}};
      int sum=0;
	  int length= a.length;
  	  for(int i=0;i<a.length;i++)
	  {
		  for(int j=0;j<a.length;j++)
		  {
	       sum= sum+a[i][j];
	      }
       }
	  System.out.println(" "+ sum);
	  double avg= sum/length;
	   System.out.println(" "+ avg);
	  
	 }
}
	  