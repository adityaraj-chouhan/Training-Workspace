class only14
{
   public static void main(String[] args)
   {
	   int k=0;
     int[] a= new int[] {1,4,4,1,4};
     int sum=0;
	
	 int length= a.length;
  	 for(int i=0;i<a.length;i++)
	   { 
         if(a[i]==1 || a[i]==4 )
          {
	        k++;
          } 
   
        } 
      if (k==a.length)
	  {
		     System.out.println("true");
	  }
      else
      {   System.out.println("false");
	   }
	   }
   }

