class elementInArray 
{
   public static void main(String[] args)
   {
     int[] a= new int[] {1,2,3,4,5};
      int f=Integer.parseInt(args[0]);
	  int length= a.length;
  	  for(int i : a)
	  {
	   if(i==f)
	     {
		 System.out.println(" present "+ f);
		 }
	
	  
	  }
	 
	  
	  }
}
	  