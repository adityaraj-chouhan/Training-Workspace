class sumOfArrayWithCondition
{
   public static void main(String[] args)
   {
     int[] a= new int[] {1,6,3,7,5};
     int sum=0;
	 boolean add=true;
	 int length= a.length;
  	 for(int i=0;i<a.length;i++)
	   {
	    if(a[i]!=6 && add==true)
        sum=sum+a[i];
          else if(a[i]==6)
            {
              if((i=1)==a.length)
                {
				sum=sum+a[i];
			    }
				else
				add =false;
				}
				else if (a[i] ==7)
				add = true;
				}
				System.out.println(sum);
				}
				}
				
				