use adityaraj;
create table exportDemo(decimalValues decimal(65,30),integerValues int(30), dateValue date,timeValue time,datetimeValue datetime,timestampValue timestamp, characterValue char, string varchar(50) );
insert into exportDemo values(34.32,4,"3022-04-04","19:30:30","2022-03-25 23:33:44","2022-03-25 19:30:30",'c',"adi");
select * from exportDemo;
show tables;
create temporary table xyz select * from exportDemo;
select * from xyz;
drop temporary table xyz;
 select now();
 alter table exportDemo change integerValues integerValue int (46);
 alter table exportDemo rename  exportDemoo;
  alter table exportDemoo rename  exportDemo;
 
 
 


