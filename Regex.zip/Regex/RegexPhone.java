import java.util.regex.*;    
	import java.util.*;    
public class RegexPhone {
	public static void main(String args[]){  
        ArrayList<String> phone = new ArrayList<String>();  
        phone.add("56464578");  
        phone.add("907862534");  
        phone.add("6345776889"); 
        phone.add("3456789098");  
        String regex = "\\d{10}"; 
        Pattern pattern = Pattern.compile(regex);  
        for(String s : phone){    
            Matcher m = pattern.matcher(s);
            System.out.println(s +" : "+ m.matches()+"\n");  
        }  
    }  
}  



