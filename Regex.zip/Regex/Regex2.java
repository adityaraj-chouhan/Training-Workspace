	import java.util.Arrays;
public class Regex2 {
	public static void main(String args[]){
	        String input = "hello world\r yash tech\n indore";
	        String[] linesArr = input.split("\\r|\\n|\\r");
	        System.out.println(Arrays.toString(linesArr));
	    }
	}

