	import java.util.regex.*;    
	import java.util.*;    
public class RegexEmail {
	public static void main(String args[]){  
	        ArrayList<String> emails = new ArrayList<String>();  
	        emails.add("abc@yash.com");  
	        emails.add("xyz@google.com");  
	        emails.add("asd@yahoo.com"); 
	        emails.add("@yahoo.com");  
	        String regex = "^(.+)@(.+)$";  
	        Pattern pattern = Pattern.compile(regex);  
	        for(String email : emails){    
	            Matcher m = pattern.matcher(email);  
	            System.out.println(email +" : "+ m.matches()+"\n");  
	        }  
	    }  
	}  
