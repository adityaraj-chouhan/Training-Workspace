	import java.util.regex.*;    
	import java.util.*;    
public class RegexUrl {
	public static void main(String args[]){  
        ArrayList<String> url = new ArrayList<String>();  
      url.add("https://www.google.com" );  
      url.add("https:  //www.google.com");    
        String regex ="https://"  ;  
        Pattern pattern = Pattern.compile(regex);  
        for(String email : url){    
            Matcher m = pattern.matcher(email);  
            System.out.println(email +" : "+ m.matches()+"\n");  
        }  
        
    }  
}  

