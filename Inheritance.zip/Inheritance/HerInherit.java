class HerInherit
{
void disp()
{
System.out.println("A");
}
}
class B extends SingleInherit
{
void dispB()
{
System.out.println("B");
}
}
class C extends HerInherit
{
void dispC()
{
System.out.println("C");
}
public static void main(String[] args)
{
C obj= new C();
obj.disp();
}
}
