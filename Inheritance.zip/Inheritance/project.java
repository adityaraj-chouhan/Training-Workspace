class Student
{
String name;
int dateOfBirth;
int enrollment;
String result;
  Student(String name ,int dateOfBirth ,int enrollment, int result)
  {
	  this.name=name;
	  this.dateOfBirth=dateOfBirth;
	  this.enrollment=enrollment;
	  this.result=result;
  }	  
}


class FirstYear extends Student
{
  boolean feesPaid;
  FirstYear(String name ,int dateOfBirth,int enrollment, int result ,boolean feesPaid)
  { 
      super (name, dateOfBirth , enrollment,result);
	  this.feesPaid=feesPaid;
  }
  void display()
  {
	  System.out.println( super.name + super.dateOfBirth + super.enrollment+ super.result+ feesPaid);
  }
 
}

class SecondYear extends Student
{
  boolean feesPaid;
  FirstYear(String name ,int dateOfBirth,int enrollment, int result ,boolean feesPaid)
  { 
      super (name, dateOfBirth , enrollment,result);
	  this.feesPaid=feesPaid;
  }
  void display()
  {
	  System.out.println( super.name + super.dateOfBirth + super.enrollment+ super.result+ feesPaid);
  }
 
}


class ThirdYear extends Student
{
  boolean feesPaid;
  FirstYear(String name ,int dateOfBirth,int enrollment, int result ,boolean feesPaid)
  { 
      super (name, dateOfBirth , enrollment,result);
	  this.feesPaid=feesPaid;
  }
  void display()
  {
	  System.out.println( super.name + super.dateOfBirth + super.enrollment+ super.result+ feesPaid);
  }
 
}

class FourthYear extends Student
{
   boolean feesPaid;
   FirstYear(String name ,int dateOfBirth,int enrollment, int result ,boolean feesPaid)
  { 
      super (name, dateOfBirth , enrollment,result);
	  this.feesPaid=feesPaid;
  }
  void display()
  {
	  System.out.println( super.name + super.dateOfBirth + super.enrollment+ super.result+ feesPaid);
  }
 
}



class Faculty
{
String name;
int dateOfBirth;
int enrollment;
String result;
  Student(String name ,int dateOfBirth ,int enrollment, int result)
  {
	  this.name=name;
	  this.dateOfBirth=dateOfBirth;
	  this.enrollment=enrollment;
	  this.result=result;
  }	  
}
class Student extends Student
{
int studentid;
Student(String name ,int dateOfBirth,int studentid)
{
	super(name , dateOfBirth);
	this.studentid=studentid;
}
void display()
  {
	  System.out.println( super.name +super.dateOfBirth+ studentid);
  }
 

}


class CollegeStudent extends Student
{
String collegeName;
int year;
 CollegeStudent(String name ,int dateOfBirth ,int studentid ,String CollegeName, int year)
 {
	 super(name,dateOfBirth,studentid);
	 this.collegeName=collegeName;
	 this.year =year;
 }
 void display()
  {
	 System.out.println(super.name +super.dateOfBirth +super.studentid + collegeName+ year);
	  
  }
    public static void main(String[] args)
{    CollegeStudent c= new CollegeStudent("abc", 1,2,"xyz",3);
	Teacher t = new Teacher("adi",1 ,2 ,"sci" );
	Student s= new Student ("adi",1,2);
c.display();


}
}

