class MethodOverriding //vehicle
{
void run()
{
System.out.println("running");

}
}
class Bike extends MethodOverriding
{
 void run()
{
System.out.println("bike is running");

}
public static void main(String[] args)
{
Bike obj= new Bike();
obj.run();
}

}
