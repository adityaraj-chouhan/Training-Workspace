class Author
{
private String name;
private String email;
private char gender;
 Author(String name,String email,char gender)
     {
	 this.name= name;
	 this.email= email;
	 this.gender=gender;
	 }
	 
	 public String getName()
	 { return name;}
	 public String getemail()
	 { return email;}
	 public String getgender()
	 { return gender;}
	 
 public static void main(String[] args)
	 {
	 }
public class Book extends Author
	 {
		
	 private String name;
	 private double price;
	 private int qtyInStock;
	 private Author author;
	 
	 public Book(String name, Author author ,double price, int qtyInStock)
	 {
	 this.author=new author("ADITYA","xyz",'M');
	 this.name= name;
	 this.price= price;
	 this.qtyInStock=qtyInStock;
	 }
	
	  public Author getAuthor()
	 { return this.Author;}
	  public String getname()
	 { return name;}
	  public double getprice()
	 { return price;}
	  public int getqtyInStock()
	 { return qtyInStock;}
	 
	 
	 public void setAuthor(Author newAuthor)
	 {
	 Author=newAuthor;
	 }
	 public void setname(String name)
	 {
	 this.name=name;
	 }
	 public void setprice(double price)
	 {
	 this.price=price;
	 }
	 public void setqtyInStock(int qtyInStock)
	 {
	 this.qtyInStock = qtyInStock;
	 }
	
	 
	  public String toString()
	 {
		 return "price" + this.price +"name"+ this.name +"Author" +this.Author +"qtyInStock" +this.qtyInStock;
	 }
	 
	 
	 }
}

	 
	 
	 
