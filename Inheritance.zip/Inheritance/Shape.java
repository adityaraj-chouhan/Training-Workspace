class Shape
{
  void draw()
  {
   System.out.println("drawing");
  }  
  void erase()
  {
   System.out.println("erasing");
  }
}

class Circle extends Shape
{
  void draw()
  {
   System.out.println("drawing circle");
  }
  void erase()
  {
   System.out.println("erasing circle");
  }
}

class Triangle extends Shape
{
  void draw()
  {
   System.out.println("drawing Triangle");
  }
  void erase()
  {
   System.out.println("erasing Triangle");
  }
}

class Square extends Shape
{
  void draw()
  {
   System.out.println("drawing Square");
  }
  void erase()
  {
   System.out.println("erasing Square");
  }
public static void main(String[] args)
{
Shape s= new Shape();
Circle c= new Circle();
Square sq= new Square();
Triangle t= new Triangle();
s.draw();
s.erase();
c.draw();
c.erase();
t.draw();
t.erase();
sq.draw();
sq.erase();


}

}
