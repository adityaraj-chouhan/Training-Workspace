class MethodLoad
{
void show(int a)
{
System.out.println("yash");
}
void show(String a)
{
System.out.println("technologies");
}
  public static void main(String[] args)
  {
  MethodLoad obj= new MethodLoad();
  obj.show(10);
   obj.show("tech");
  
  }
}
