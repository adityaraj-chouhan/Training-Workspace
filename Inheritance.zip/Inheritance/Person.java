
class Person
{
String name;
int dateOfBirth;
  Person(String name ,int dateOfBirth)
  {
	  this.name=name;
	  this.dateOfBirth=dateOfBirth;
  }	  
}



class Teacher extends Person
{
int salary;
String subject;
  Teacher(String name ,int dateOfBirth,int salary, String subject)
  { 
       super (name,dateOfBirth);
	  this.salary=salary;
	  this.subject=subject;
	  this.salary=salary;
  }
  void display()
  {
	  System.out.println( super.name + super.dateOfBirth + salary +  subject);
  }
 
}



class Student extends Person
{
int studentid;
Student(String name ,int dateOfBirth,int studentid)
{
	super(name , dateOfBirth);
	this.studentid=studentid;
}
void display()
  {
	  System.out.println( super.name +super.dateOfBirth+ studentid);
  }
 

}


class CollegeStudent extends Student
{
String collegeName;
int year;
 CollegeStudent(String name ,int dateOfBirth ,int studentid ,String CollegeName, int year)
 {
	 super(name,dateOfBirth,studentid);
	 this.collegeName=collegeName;
	 this.year =year;
 }
 void display()
  {
	 System.out.println(super.name +super.dateOfBirth +super.studentid + collegeName+ year);
	  
  }
    public static void main(String[] args)
{    CollegeStudent c= new CollegeStudent("abc", 1,2,"xyz",3);
	Teacher t = new Teacher("adi",1 ,2 ,"sci" );
	Student s= new Student ("adi",1,2);
c.display();


}
}

