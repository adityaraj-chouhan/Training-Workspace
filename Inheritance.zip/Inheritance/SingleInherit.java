class SingleInherit
{
void disp()
{
System.out.println("A");
}
}
class B extends SingleInherit
{
public static void main(String[] args)
{
B obj= new B();
obj.disp();
}
}
