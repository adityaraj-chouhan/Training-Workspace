class Animall
{
void eat()
{
System.out.println("eating");
}
void sleep()
{
System.out.println("sleeping");
}
}
class Bird extends Animall
{
void eat()
{
System.out.println("eating");
}
void sleep()
{
System.out.println("sleeping");
}
 void fly()
{
System.out.println("flying");
}
public static void main(String[] args)
{
Bird obj= new Bird();
obj.sleep();
obj.eat();
obj.fly();
Animall obj1= new Animall();
obj1.eat();
obj1.sleep();

}

}
