
public class A {
	public void doTask(){
		System.out.println("application context aware");
	}
}
