package com.yash.springorm;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springorm.dao.StudentDao;
import com.yash.springorm.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		StudentDao studao = context.getBean("studentDao", StudentDao.class);
		Student stu = new Student(2, "singh");

		System.out.println("Please choose from menu:");
		System.out.println("1. INSERT STUDENT DETAILS");
		System.out.println("2. UPDATE STUDENT DETAILS");
		System.out.println("3. DELETE STUDENT DETAILS");
		System.out.println("4. VIEW STUDENT DETAIL");
		System.out.println("5. VIEW ALL STUDENT DETAILS");

		Scanner input = new Scanner(System.in);
		System.out.println("Enter Username");
		String userName = input.nextLine();

		System.out.println("Enter password");
		String password = input.nextLine();

		//if ("aditya".equals(userName) && "password".equals(password)) {
		//	System.out.println("successful login");

			int option = input.nextInt();
			input.close();

			if (option == 1) {
				int msg = studao.insert(stu);
				System.out.println(msg + "insertion done");
			} else if (option == 2) {
				studao.update(stu);
				System.out.println("updation done");

			} else if (option == 3) {
				studao.delete(stu);
				System.out.println("deletion done");
			} else if (option == 4) {
				System.out.println("details are" + studao.get(1));
			} else if (option == 5) {
				System.out.println("details are" + studao.loadAll());
			} else {
				System.out.println("invalid");
			}

		}

		//else {

			//System.out.println("login failed");

		//}
	}

