package com.yash.springorm.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.orm.hibernate5.HibernateTemplate;

import com.yash.springorm.entities.Student;

public class StudentDao {
	private HibernateTemplate hibernatetemp;

	@Transactional
	public int insert(Student stu) {
		Integer i = (Integer) this.hibernatetemp.save(stu);
		return i;

	}

	@Transactional
	public void update(Student stu) {
		this.hibernatetemp.update(stu);
	}

	@Transactional
	public void delete(Student stu) {
		this.hibernatetemp.delete(stu);
	}

	public Student get(int stuid) {
		Student stu = this.hibernatetemp.get(Student.class, stuid);
		return stu;
	}

	public List<Student> loadAll() {
		List<Student> stu = this.hibernatetemp.loadAll(Student.class);
		return stu;
	}

	public HibernateTemplate getHibernatetemp() {
		return hibernatetemp;
	}

	public void setHibernatetemp(HibernateTemplate hibernatetemp) {
		this.hibernatetemp = hibernatetemp;
	}

}
