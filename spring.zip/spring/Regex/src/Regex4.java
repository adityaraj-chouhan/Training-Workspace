import java.util.regex.*;
public class Regex4{
	public static void main(String args[]){
		Pattern p = Pattern.compile("raj");
		Matcher m = p.matcher("Aditya raj ");
		while(m.find()){
			System.out.println(m.group()+" Position of that string "+m.start());
		}

	}
}
