import java.util.regex.*;
class Regex1{
	public static void main(String args[]){
		Pattern p = Pattern.compile("\\d");
		Matcher m = p.matcher("adityarajchouhan786");
		while(m.find()){

			System.out.println(m.group()+" Position of that number "+m.start());
			}
	}
}
