package springsecondapp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import springsecondapp.Employee;

public class App {
	public static void main(String[] args) {
		System.out.println("welcome to spring second app");
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		Employee e = (Employee) context.getBean("employee");
		System.out.print(e);
		Employee e1=(Employee) context.getBean("employee1");
		System.out.println(e1);
	}

}
