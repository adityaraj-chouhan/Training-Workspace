package springconstructorinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import springconstructorinjection.Employee;

public class App {
	public static void main(String[] args) {
		System.out.println("welcome to spring contructor injection app");
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		Employee e = (Employee) context.getBean("employee");
		System.out.print(e);
		

	}


}
