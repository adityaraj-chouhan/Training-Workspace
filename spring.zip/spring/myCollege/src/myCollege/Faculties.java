package myCollege;

abstract public class Faculties {
	String name;
	int id;
	String department;

	Faculties(String name ,int id , String department){
		this.name=name;
		this.id=id;
		this.department=department;
	}
	
	public abstract void display();
	

}
