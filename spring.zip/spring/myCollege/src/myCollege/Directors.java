package myCollege;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Directors extends Faculties {
	
	int salary ;
	
	public Directors(String name ,int id , String department, int salary){
		super(name,id,department);
		this.salary=salary;
	}
	
	@Override
	public void display(){
		System.out.println( "NAME="+name+ "  "+ "  ID=" +id+ " "+"  DEPARTMENT="+department + " "+"  SALARY="+salary);
	}
	
	public void directorDatabase(){
		try{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//create connection
			String url= "jdbc:mysql://localhost:3306/mycollege";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			// creating query
			String q= "insert into Directors values(?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(q);
			// setting the values
			
			ps.setString(1, "Rohit");
			ps.setInt(2,670);
			ps.setString(3, "Civil");
			ps.setInt(4,98000);
			
			
			ps.executeUpdate();
			System.out.println("inserted");
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
}

