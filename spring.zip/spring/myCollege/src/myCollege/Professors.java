package myCollege;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Professors extends Faculties {
	int salary;

	public Professors(String name, int id, String department, int salary) {
		super(name, id, department);
		this.salary = salary;
	}

	@Override
	public void display() {
		System.out.println(
				"NAME=" + name + "  " + "  ID=" + id + " " + "  DEPARTMENT=" + department + " " + "  SALARY=" + salary);
	}

	public void professorsDatabase() {
		try {
			// load the driver
			Class.forName("com.mysql.jdbc.Driver");
			// create connection
			String url = "jdbc:mysql://localhost:3306/mycollege";
			String user = "root";
			String pass = "root";
			Connection con = DriverManager.getConnection(url, user, pass);
			// creating query
			String q = "insert into professors values(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(q);
			// setting the values

			Scanner input = new Scanner(System.in);
			System.out.println("name=");
			String name = input.nextLine();

			ps.setString(1, name);

			System.out.println("id=");
			int id = input.nextInt();

			ps.setInt(2, id);

			System.out.println("department=");
			String department = input.nextLine();

			ps.setString(3, department);

			System.out.println("salary=");
			int salary = input.nextInt();

			ps.setInt(4, salary);

		

			ps.executeUpdate();
			input.close();

			System.out.println("inserted");

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
