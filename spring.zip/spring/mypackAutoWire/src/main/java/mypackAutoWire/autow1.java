package mypackAutoWire;

public class autow1 {
	autow1() {
		System.out.println(" autow1  is created");
	}

	void print() {
		System.out.println("hello  autow1 ");
	}

}
