package com.Lifecyclexml;

public class HelloWorld {
	private String message;

	public String getMessage() {
		System.out.println("your message" + message);
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void init() {
		System.out.println("bean is going throgh init");
	}

	public void destroy() {
		System.out.println("bean is destroying");
	}

}
