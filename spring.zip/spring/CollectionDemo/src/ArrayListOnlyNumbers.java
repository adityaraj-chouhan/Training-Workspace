
import java.util.ArrayList;
import java.util.List;

public class ArrayListOnlyNumbers<E> extends ArrayList<E>{
	
	public boolean add(E e) {
		if( e instanceof Integer|| e instanceof Float || e instanceof Double) {
			super.add(e);
			return true;
		}
		else {
			throw new ClassCastException("only numbers allowed");
		}
	}
	
	public static void main(String[] args) {
		ArrayList a= new ArrayList();
		try {
			a.add(15);
			a.add(38.7);
			}
		catch (Exception e) {
			e.printStackTrace();
		}
	System.out.println(a);
	
	}
}
