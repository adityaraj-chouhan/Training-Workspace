
import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayListIterator {
	public static void main(String[] args) {
		ArrayList<String> a= new ArrayList<String>();
		a.add("A");
		a.add("B");
		a.add("C");
		a.add("D");
		System.out.println(a);
		ListIterator li= a.listIterator();
		li.next();//B
		li.next();//C
		while(li.hasPrevious())
		{
			System.out.println(li.previous());
		}
		li.set("Technologies");
		System.out.println(a);
		
		
	

}




}
