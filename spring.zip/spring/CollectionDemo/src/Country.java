import java.util.HashSet;
import java.util.Iterator;
public class Country {
	HashSet<String> a= new HashSet<String>();
	public HashSet<String> saveCountryNames(String countryName){
		a.add(countryName);
		return a;
	}
	public String getCountry(String CountryName) {
		Iterator<String> i=a.iterator();
		while(i.hasNext()) {
			if(i.next().equals(CountryName));
			return CountryName;
		}
		return null;
		
	}
	
	
	public static void main(String[] args) {
		Country c=new Country();
		c.saveCountryNames("india");
		c.saveCountryNames("pakistan");
		System.out.println(c.getCountry("india"));
		
	}

}
