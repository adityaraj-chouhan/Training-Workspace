
import java.util.ArrayList;
import java.util.ListIterator;
public class ArrayListIteratorMonth {
	public static void main(String[] args) {
		ArrayList<String> a= new ArrayList<String>();
		a.add("jan");
		a.add("Feb");
		a.add("march");
		a.add("april");
		a.add("may");
		a.add("june");
		a.add("july");
		a.add("aug"); 
		a.add("sept");
		a.add("oct");
		a.add("nov");
		a.add("dec");
		System.out.println(a);
		ListIterator li= a.listIterator();
		li.next();
		li.next();
		while(li.hasPrevious())
		{
			System.out.println(li.previous());
		}
		li.set("Technologies");
		System.out.println(a);		

 }
}
