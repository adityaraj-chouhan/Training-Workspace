import java.util.ArrayList;
public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList a= new ArrayList();
		a.add(100);
		a.add("yash");
		a.add('a');
		System.out.println(a);
	}

}
