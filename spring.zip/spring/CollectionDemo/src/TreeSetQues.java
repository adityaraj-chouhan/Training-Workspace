
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;
public class TreeSetQues {
	public static void main(String[] args) {
		TreeSet<String> a= new TreeSet<String>();
		a.add("adi");
		a.add("shivam");
		a.add("ritik");
		a.add("pranav");
		//System.out.println(a);
		Iterator i=a.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		
		}
		
		
		Set<String> s=a.descendingSet();
		Iterator itr1=s.iterator();
		while(itr1.hasNext())
		{
			System.out.println(itr1.next());
		
		}
		
		
		
		System.out.println(a.contains("adi")); 
	}

}
