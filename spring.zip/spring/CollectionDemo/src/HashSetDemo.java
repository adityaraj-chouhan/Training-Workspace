import java.util.HashSet;
import java.util.Iterator;


public class HashSetDemo {
	public static void main(String[] args) {
		HashSet<String> a= new HashSet<String>();
		a.add("one");
		a.add("two");
		a.add("three");
		a.add("four");
		System.out.println(a);
		Iterator i=a.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		
		}
		for(String j:a) {
			System.out.println(" "+j);
		}
	}

}
