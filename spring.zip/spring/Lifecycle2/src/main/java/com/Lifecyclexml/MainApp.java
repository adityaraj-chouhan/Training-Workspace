package com.Lifecyclexml;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
	public static void main(String[] args) {
	    //  AbstractApplicationContext context = new ClassPathXmlApplicationContext("Bean.xml");
//
	   //   HelloWorld obj = (HelloWorld) context.getBean("helloWorld");
	   //   obj.getMessage();
	   //   context.registerShutdownHook();
	   //}
	    
	     
	      
	      ConfigurableApplicationContext cap
	      = new ClassPathXmlApplicationContext(
	      "Bean.xml"); // It will close the Spring container
	      // and as a result invokes the
	      // destroy() method
	      cap.close();
	}

}
