package com.Lifecyclexml;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
 
public class HelloWorld {
	private String message;

	public String getMessage() {
		System.out.println("your message" + message);
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	@PostConstruct
	public void init() throws Exception{
		System.out.println("bean is going throgh init");
	}
	@PreDestroy
	public void destroy() throws Exception{
		System.out.println("bean is destroying");
	}
	
	

}
