import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class ClobFileInsertion {
	public static void main(String[] args) {
		try{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//create connection
			String url= "jdbc:mysql://localhost:3306/adityaraj";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			String q= "insert into document(article) values(?)";
			System.out.println("Connection established......");
			PreparedStatement ps=con.prepareStatement(q);
			ps.setString(1,"sample file");
			//InputStream in = new FileInputStream("D:\\notes\\1.PNG");
			FileReader reader = new FileReader("D:\\yash\\xyz.txt");
			ps.setClob(1,reader);
			ps.executeUpdate();
			System.out.println("inserted");
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
