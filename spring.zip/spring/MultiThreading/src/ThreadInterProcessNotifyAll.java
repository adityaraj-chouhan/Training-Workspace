class Revenue2 extends Thread{
	int total=0;
	public void run() {
		synchronized(this) {
			for(int i=1;i<=5;i++) {
				total=total+400;
			}
			this.notifyAll();
		}
	}
}
class Telecast extends Thread{
	 public void run() {
		 System.out.println("total amount to be displayed");
	 }
		
}

public class ThreadInterProcessNotifyAll{
	public static void main(String[] args) throws Exception {
		Revenue r=new Revenue();
		r.start();// thread-0
		Telecast t=new Telecast();
		t.start();
		
		
		synchronized(r) {
			r.wait(3000);
			System.out.println("total Amount="+ r.total);
		}
	}

}




