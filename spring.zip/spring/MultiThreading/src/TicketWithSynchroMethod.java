/*class BookTicket{
	int totalseats=12;
	synchronized void bookseat(int seats){
		if(totalseats>=seats) {
			System.out.println("book successful");
			totalseats=totalseats-seats;
			System.out.println("remaining seats"+totalseats);
		}
		else {
			System.out.println("seats are not available"+ totalseats);
		}
	}
}*/
public class TicketWithSynchroMethod extends Thread {
	static BookTicket b;
	int seats;
	public void run() {
		b.bookseat(seats);
		
	}
	public static void main(String[] args) {
		b=new BookTicket();
		TicketWithSynchroMethod  p1=new TicketWithSynchroMethod ();
		p1.seats=8;
		p1.start();
		TicketWithSynchroMethod  p2=new TicketWithSynchroMethod ();
		p2.seats=10;
		p2.start();
		
		
	}

}



