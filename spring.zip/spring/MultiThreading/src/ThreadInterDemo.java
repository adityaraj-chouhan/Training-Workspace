
public class ThreadInterDemo extends Thread {
	public void run() {
		System.out.println(Thread.interrupted());
		//System.out.println(Thread.currentThread().isInterrupted());
		System.out.println(Thread.interrupted());
		try {
			for(int i=1;i<=3;i++) {
				System.out.println(i);//1
				Thread.sleep(2000);
			}
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	public static void main(String[] args) {
		ThreadInterDemo ti=new ThreadInterDemo();
		ti.start();
		ti.interrupt();
	}

}

	
		
		


