
public class ThreadNameDemo2 extends Thread{
	public void run() {
		Thread.currentThread().setName("Run");
		System.out.println("Run:"+Thread.currentThread().getName());
	}
	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName());
		ThreadNameDemo2 t1=new ThreadNameDemo2();
		t1.setName("T1 Thread");
		t1.start();
		ThreadNameDemo2 t2=new ThreadNameDemo2();
		t2.setName("T2 Thread");
		t2.start();
	}
}
