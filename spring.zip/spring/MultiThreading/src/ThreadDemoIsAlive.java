
public class ThreadDemoIsAlive extends Thread {
	public void run() {
		Thread.currentThread().setName("Run");
		System.out.println("Run:"+Thread.currentThread().getName());
	}
	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName());
		ThreadDemoIsAlive t1=new ThreadDemoIsAlive();
		System.out.println(t1.isAlive());
		t1.setName("T1 Thread");
		t1.start();
		System.out.println(t1.isAlive());
		System.out.println(Thread.currentThread().isAlive());
		ThreadDemoIsAlive t2=new ThreadDemoIsAlive();
		t2.setName("T2 Thread");
		t2.start();
	}
}


