// single task multiple thread
public class ThreadDemo2 extends Thread {
	public void run() {
		System.out.println("thread started");
	}
	public static void main(String[] args) {
		ThreadDemo2 t =new ThreadDemo2();
		t.start();
		ThreadDemo2 t1 =new ThreadDemo2();
		t1.start();
		
		
	}

}
