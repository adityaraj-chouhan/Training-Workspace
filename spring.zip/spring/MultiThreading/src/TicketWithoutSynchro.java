/*class BookTicket{
	int totalseats=12;
	void bookseat(int seats){
		if(totalseats>=seats) {
			System.out.println("book successful");
			totalseats=totalseats-seats;
			System.out.println("remaining seats"+totalseats);
		}
		else {
			System.out.println("seats are not available"+ totalseats);
		}
	}
}*/
public class TicketWithoutSynchro extends Thread {
	static BookTicket b;
	int seats;
	public void run() {
		b.bookseat(seats);
		
	}
	public static void main(String[] args) {
		b=new BookTicket();
		TicketWithoutSynchro p1=new TicketWithoutSynchro();
		p1.seats=8;
		p1.start();
		TicketWithoutSynchro p2=new TicketWithoutSynchro();
		p2.seats=10;
		p2.start();
		
		
	}

}
