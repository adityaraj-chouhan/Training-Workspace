
public class ThreadPriorityDemo extends Thread {
	public void run() {

		System.out.println("Run:"+Thread.currentThread().getPriority());
	}
	public static void main(String[] args) {
		
		System.out.println(Thread.currentThread().getPriority());
		Thread.currentThread().setPriority(MIN_PRIORITY);
		System.out.println(Thread.currentThread().getPriority());
		ThreadPriorityDemo tp=new ThreadPriorityDemo();
		tp.start();
	}
}
