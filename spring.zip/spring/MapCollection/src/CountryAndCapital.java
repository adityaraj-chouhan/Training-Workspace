import java.util.HashMap;
public class CountryAndCapital {
	public static HashMap hm = new HashMap();




	public void saveCountry(String countryname, String capital)
	{
	hm.put(countryname,capital);

	}



	public void getCapital(String countryname)
	{

	String val = (String)hm.get(countryname);
	System.out.println(val);
	}
	public void getCountry(String capital)
	{
	String val = (String)hm.get(capital);
	String key = val;


	}
    
	


public static void main(String args[])
	{
	CountryAndCapital h= new CountryAndCapital();
	h.saveCountry("INDIA","delhi");
	h.saveCountry("japan","Tokyo");
	h.getCapital("japan");
	h.getCountry("delhi");





	}
	}




