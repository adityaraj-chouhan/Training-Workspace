import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;



public class HashMapQues {
	public static void main(String[] args) {
		{
			
			HashMap<Integer, String>hm = new HashMap<>();
			hm.put(1, "aditya");
			hm.put(2, "raj");
			hm.put(3, "yash");
			int k = 4;
			System.out.println( hm);


			Iterator<Map.Entry<Integer, String> > i = hm.entrySet().iterator();
			String v="yash";
			boolean ans = false;
			boolean val=false;

			while (i.hasNext()) {
				Map.Entry<Integer, String>entry= i.next();


				if (k == entry.getKey()) {

					ans = true;
				}
				if (v == entry.getValue()) {

					val = true;
				}
			}


			System.out.println("key present "+ans);
			System.out.println("key present "+val);



			}
			}
}
