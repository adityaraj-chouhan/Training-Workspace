package com.yash.springjdbc.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.entities.*;

public class StudentDaoImpl implements StudentDao {
	private JdbcTemplate jdbctemp;

	public int insert(Student stu) {

		String q = "insert into employee(empname,emailid,dob,contactno,salary) values(?,?,?,?,?)";
		int msg = this.jdbctemp.update(q, stu.getEmpname(), stu.getEmailid(), stu.getDob(), stu.getContactno(),stu.getSalary());
		return msg;
	}
	
	public int updatedetails(Student stu) {
		// update details of employee
		String q="update employee set empname=?, emailid=?,contactno=?,salary=? where dob=?";
		int msg = this.jdbctemp.update(q, stu.getEmpname(), stu.getEmailid(), stu.getDob(), stu.getContactno(),stu.getSalary());
		return msg;
		}

	
	public int deletedetails(int stu) {
		// T0 delete  
		String q="delete from employee where contactno=?";
		int msg=this.jdbctemp.update(q,stu);

		return msg;

		}

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

}
