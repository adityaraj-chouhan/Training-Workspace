package com.yash.springjdbc.entities;

public class Student {
	private String empname;
	private String emailid;
	private int dob;
	private int contactno;
	private int salary;

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String email) {
		this.emailid = email;
	}

	public int getDob() {
		return dob;
	}

	public void setDob(int dob) {
		this.dob = dob;
	}

	public int getContactno() {
		return contactno;
	}

	public void setContactno(int contactno) {
		this.contactno = contactno;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Student [empname=" + empname + ", email=" + emailid + ", dob=" + dob + ", contactno=" + contactno
				+ ", salary=" + salary + "]";
	}

	

	public Student(String empname, String email, int dob, int contactno, int salary) {
		super();
		this.empname = empname;
		this.emailid = email;
		this.dob = dob;
		this.contactno = contactno;
		this.salary = salary;
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

}
