package com.yash.springjdbcdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");

		StudentDao stdao = context.getBean("StudentDao", StudentDao.class);

		Student s = new Student();
		s.setEmpname("aditya");
		s.setEmailid("aditya@gmail.com");
		s.setDob(1209);
		s.setContactno(1209);
		s.setSalary(1209);
		
		//int r = stdao.insert(s);
		//System.out.println(r + "Student added Successfully ");

		//int r = stdao.updatedetails(s);
		//System.out.println("details updated");
		
		int r=stdao.deletedetails(1209);//delete the details
		System.out.println(r + "Student deleted Successfully ");

	}
}
