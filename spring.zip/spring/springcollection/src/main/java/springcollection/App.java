package springcollection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import springcollection.Employee;

public class App {
	public static void main(String[] args) {
		System.out.println("welcome to spring collection injection app");
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		Employee e = (Employee) context.getBean("employee");
		e.getAddressList();
		e.getAddressSet();
		e.getAddressMap();
		e.getAddressProp();

	}
}
