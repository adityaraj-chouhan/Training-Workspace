package com.yash.technology;

import java.sql.*;

public class DTOConnection {
	public static Connection getConnection() throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String user = "root";
		String pass = "root";
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/adityaraj", user, pass);
		return c;
	}

}
