package com.yash.technology;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.LinkedList;
import java.util.List;
@WebServlet("/DisplayData")
public class DisplayData extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		List<Employee> lst=Operation.getData();
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<table border='1px solid black'> ");
		pw.println("<thead>");
		pw.println("<th>Code</th>");
		pw.println("<th>Name</th>");
		pw.println("<th>Gender</th>");
		pw.println("<th>Salary</th>");
		pw.println("</thead>");
		pw.println("<tbody>");
		Employee emp=null;
		for(int i=0;i<lst.size();i++)
		{
			emp=lst.get(i);
			pw.println("<tr>");
			pw.println("<td>"+emp.getCode()+"</td>");
			pw.println("<td>"+emp.getName()+"</td>");
			pw.println("<td>"+emp.getGender()+"</td>");
			pw.println("<td>"+emp.getSalary()+"</td>");
			pw.println("</tr>");
		}
		pw.println("</tbody>");
		pw.println("</table>");
		
		pw.print("<a href ='index.html'>Home</a>");
		pw.close();
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
