package com.yash.technology;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class Operation {
	public static int addData(Employee employee) throws Exception
	{
	
		Connection c=DTOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("insert into empcrud values (?,?,?,?)");
		ps.setInt(1,employee.getCode());
		ps.setString(2,employee.getName());
		ps.setString(3,employee.getGender());
		ps.setInt(4, employee.getSalary());
		int check=ps.executeUpdate();
		c.close();
		return check;
	}
	
	public static List<Employee> getData()
	{
		List<Employee> lst=null;
		try {
			lst=new LinkedList<>();
			Connection c=DTOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("select * from empcrud");
			ResultSet rs=ps.executeQuery();
			Employee emp=null;
			while(rs.next())
			{
				emp=new Employee();
				emp.setCode(rs.getInt(1));
				emp.setName(rs.getString(2));
				emp.setGender(rs.getString(3));
				emp.setSalary(rs.getInt(4));
				lst.add(emp);
			}
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return lst;
	}
	public static Employee getDataByCode(int code)
	{
		Employee emp=new Employee();
		try
		{
			System.out.println(code);
			Connection c=DTOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("select * from empCrud where code=?");
			ps.setInt(1, code);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				emp.setCode(rs.getInt("code"));
				emp.setName(rs.getString("name"));
				emp.setGender(rs.getString("gender"));
				emp.setSalary(rs.getInt("salary"));
				
			}
			else return null;
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return emp;
	}
	public static void updateData(String name,String gender,int salary,int code)
	{
		try
		{
		Connection c=DTOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("update empcrud set name=?,gender=?,salary=? where code=?");
		ps.setString(1, name);
		ps.setString(2, gender);
		ps.setInt(3, salary);
		ps.setInt(4, code);
		ps.executeUpdate();
		c.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		}
	public static void deleteData(int code)
	{
		try {
			Connection c=DTOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("delete from empcrud where code=?");
			ps.setInt(1, code);
			ps.executeUpdate();
			
		}catch(Exception e)
		{
			System.out.print(e);
		}
	}

}
