package com.Lifecyclexml;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class HelloWorld implements InitializingBean, DisposableBean {
	private String message;

	public String getMessage() {
		System.out.println("your message" + message);
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void afterPropertiesSet() throws Exception {
		// public void init(){
		System.out.println("bean is going throgh init");
	}

	// }
	@Override

	public void destroy() throws Exception {
		System.out.println("bean is destroying");
	}

}
