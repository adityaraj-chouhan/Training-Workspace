package com.yash.technology.DAO;
import com.yash.technology.DAO.*;
import com.yash.technology.DTO.*;
import java.util.List;
import java.util.LinkedList;

import java.sql.*;
public class CrudOperation {
public int add(Employee employee) throws SQLException,ClassNotFoundException
{
	Connection c=DTOConnection.getConnection();
	PreparedStatement ps=c.prepareStatement("insert into empCrud values(?,?,?,?)");
	ps.setInt(1,employee.getCode());
	ps.setString(2,employee.getName());
	ps.setString(3, Character.toString(employee.getGender()));
	ps.setInt(4, employee.getSalary());
	int check=ps.executeUpdate();
	c.close();
	return check;
}

public List<Employee> getEmployees() throws SQLException,ClassNotFoundException
{
	List<Employee> lst=new LinkedList<>();
	Connection c=DTOConnection.getConnection();
	PreparedStatement ps=c.prepareStatement("select * from empCrud");
	ResultSet rs=ps.executeQuery();
	Employee employee=new Employee();
	while(rs.next())
	{
		employee.setCode(rs.getInt("code"));
		employee.setName(rs.getString("name"));
		employee.setGender(rs.getString("gender").charAt(0));
		employee.setSalary(rs.getInt("salary"));
		lst.add(employee);
	}
	
	c.close();
	return lst;
}
}
