abstract class Students {
	String name;
	int attendance;	
	int enrollment;
	int result;
	
	Students(String name ,int attendance ,int enrollment, int result) {
		this.name=name;
		this.attendance=attendance;
		this.enrollment=enrollment;
		this.result=result;
	}
	
	public abstract void display();
}


public class FirstYearStudents extends Students{
	boolean feesPaid;
	public FirstYearStudents(String name, int attendance, int enrollment, int result, boolean feesPaid){	 
		super (name, attendance , enrollment, result);
		this.feesPaid=feesPaid;
		}
	@Override
	public void display(){
		System.out.println("NAME="+name+" " + " ATTENDANCE="+attendance+"%  " + " ENROLLMENT="+enrollment+" RESULT="+ result+"  FEES PAID="+ feesPaid);
		if(feesPaid==true && attendance>=75){
			System.out.println("is eligible to sit in exam");
		}
		else{
			System.out.println("not eligible to sit in exam");
		}
	}

}


public class SecondYearStudents extends Students {
	boolean feesPaid;
	public SecondYearStudents(String name ,int attendance,int enrollment, int result ,boolean feesPaid){ 
		super (name, attendance , enrollment,result);
		this.feesPaid=feesPaid;
	}
	
	public void display(){
		System.out.println("NAME="+name+" " + " ATTENDANCE="+attendance+"%  " + " ENROLLMENT="+enrollment+" RESULT="+ result+"  FEES PAID="+ feesPaid);
		if(feesPaid==true && attendance>=75){
				System.out.println("is eligible to sit in exam");
		}
		else{
				System.out.println("not eligible to sit in exam");
		}
	}

}

public class ThirdYearStudents extends Students  {
	boolean feesPaid;
	public ThirdYearStudents(String name ,int attendance,int enrollment, int result ,boolean feesPaid){ 
		super (name, attendance , enrollment,result);
		this.feesPaid=feesPaid;
	}
	
	
	@Override
	public void display(){
		System.out.println("NAME="+name+" " + " ATTENDANCE="+attendance+"%  " + " ENROLLMENT="+enrollment+" RESULT="+ result+"  FEES PAID="+ feesPaid);
		
		if(feesPaid==true && attendance>=75){
			System.out.println("is eligible to sit in exam");
		}
		else{
			System.out.println("not eligible to sit in exam");
		}
	}

}

public class FourthYearStudents extends Students {
	boolean feesPaid;
	public FourthYearStudents(String name ,int attendance,int enrollment, int result ,boolean feesPaid){ 
		super (name, attendance , enrollment,result);
		this.feesPaid=feesPaid;
	}
	@Override
	public void display(){
		System.out.println("NAME="+name+" " + " ATTENDANCE="+attendance+"%  " + " ENROLLMENT="+enrollment+" RESULT="+ result+"  FEES PAID="+ feesPaid);
		if(feesPaid==true && attendance>=75){
			System.out.println("is eligible to sit in exam");
		}
		else{
			System.out.println("not eligible to sit in exam");
		}
	}

}


abstract class Faculties {
	String name;
	int id;
	String department;

	Faculties(String name ,int id , String department){
		this.name=name;
		this.id=id;
		this.department=department;
	}
	
	public abstract void display();
	
 }

public class Directors extends Faculties {
	
	int salary ;
	
	public Directors(String name ,int id , String department, int salary){
		super(name,id,department);
		this.salary=salary;
	}
	@Override
	public void display(){
		System.out.println( "NAME="+name+ "  "+ "  ID=" +id+ " "+"  DEPARTMENT="+department + " "+"  SALARY="+salary);
	}
}


public class HeadOfDepartment extends Faculties {
	int salary ;
	public HeadOfDepartment(String name ,int id , String department, int salary){
		super(name,id,department);
		this.salary=salary;
	}
	@Override
	public void display(){
		System.out.println( "NAME="+name+ "  "+ "  ID=" +id+ " "+"  DEPARTMENT="+department + " "+"  SALARY="+salary);
	}

}



public class Professors extends Faculties {
int salary ;
	
	public Professors(String name ,int id , String department, int salary){
		super(name,id,department);
		this.salary=salary;
	}
	@Override
	public void display(){
		System.out.println( "NAME="+name+ "  "+ "  ID=" +id+ " "+"  DEPARTMENT="+department + " "+"  SALARY="+salary);
	}
	
		
	}
	
	import java.util.Scanner;

import Faculty.Directors;
import Faculty.HeadOfDepartment;
import Faculty.Professors;
import Student.FirstYearStudents;
import Student.FourthYearStudents;
import Student.SecondYearStudents;
import Student.ThirdYearStudents;

public class Main {
		static FirstYearStudents[] arr;
		static SecondYearStudents[] arr2;
		static ThirdYearStudents[] arr3;
		static FourthYearStudents[] arr4;
		static Directors[] arr5;
		static HeadOfDepartment[] arr6;
		static Professors[] arr7;
		
		public static void main(String[] args){
			createCollegeData();
			Scanner input = new Scanner(System.in);
			
			showMenu();
			
			String s = input.nextLine();
			input.close();
			switch(s){
				case "1":{
					for(int i=0;i<=arr.length-1;i++){
						arr[i].display();
					}			
				}
				break;
				case "2": {
					for(int i=0;i<=arr2.length-1;i++){
						arr2[i].display();
					}
				}
				break;
				case "3":{
					for(int i=0;i<=arr3.length-1;i++){
						arr3[i].display();
					}
				}	
				break;
				case "4": {
					for(int i=0;i<=arr4.length-1;i++){
						arr4[i].display();
					}
				}	
				break;
				case "5":{
					for(int i=0;i<=arr5.length-1;i++){
						arr5[i].display();
					}
				}	
				break;
				case "6":{
					for(int i=0;i<=arr6.length-1;i++){
						arr6[i].display();
					}
				}	
				break;
			    case "7":{
					for(int i=0;i<=arr7.length-1;i++){
						arr7[i].display();
					}
				}	
				break;
			}
		}
		
		
		private static void createCollegeData() {
			//students
			FirstYearStudents fy1  = new FirstYearStudents("Ritik Dave",83 ,30891 ,89,true);
			FirstYearStudents fy2  = new FirstYearStudents("Sahil Gupta 1",86 ,308911 ,87,true);
			arr = new FirstYearStudents[] {fy1, fy2};
			
			SecondYearStudents sy = new SecondYearStudents("Pranav Goswami",68,30892,82,false);
			arr2 = new SecondYearStudents[] {sy};
			
			ThirdYearStudents ty = new ThirdYearStudents("Chaitanya Mohta",72 ,30893 ,63,true);
			arr3 = new ThirdYearStudents[] {ty};
			
			FourthYearStudents foy = new FourthYearStudents("Vedant Patil",91 ,30894 ,77,true);
			arr4 = new FourthYearStudents[] {foy};
			
			
			//faculties
			Directors d= new Directors("Mr Vishal Bhatia",18020,"Computer Science",100000);
			arr5 = new Directors[] {d};
			
			HeadOfDepartment h1= new HeadOfDepartment("Ms Renuka Sharma",19250,"Computer Science",80000);
			HeadOfDepartment h2= new HeadOfDepartment("Mr Bharat Sharma",19250,"Civil Engineering",70000);
			arr6 = new HeadOfDepartment[] {h1,h2};
			
			Professors p1= new Professors("Mr Shivendra Singh",19930,"Computer Science",50000);
			Professors p2= new Professors("Mr Aryan Singh",19930,"Civil Engineering",50000);
			arr7 = new Professors [] {p1,p2};
		}
		
		private static void showMenu() {
			System.out.print("Please choose from menu:" 
					+ "\n 1 --> first year students."
					+ "\n 2 --> second year students."
					+ "\n 3 --> third year students."
					+ "\n 4 --> fourth year students."
					+"\n -------------------------"
					+"\n 5 --> View Directors."
					+"\n 6 --> View HeadOfDepartment."
					+"\n 7 --> View Professor.");
		}

}



