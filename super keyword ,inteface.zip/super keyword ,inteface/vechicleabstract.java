abstract class Pc
{
abstractvoid start()
}
class Pc extends Laptop
{
void start() vechicleabstract
{
System.out.println("laptop is on");
}
}
class Moblie start() Pc
{
void start()
{
System.out.println("mobile is on");
}
public static void main(String[] args)
{
Mobile	obj= new Mobile();
obj.start();
Laptop c= new Laptop();
c.start();
}
}
