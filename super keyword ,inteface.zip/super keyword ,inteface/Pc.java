abstract class Pc
{
abstract void start();
}
class Laptop extends Pc
{
void start()
{
System.out.println("laptop is on");
}
}
class Mobile extends Pc
{
void start()
{
System.out.println("mobile is on");
}
public static void main(String[] args)
{
Mobile	obj= new Mobile();
obj.start();
Laptop c= new Laptop();
c.start();
}
}
