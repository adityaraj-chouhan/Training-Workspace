public class ClassCastException
{
    public static void main(String[] args)
	{
        Object obj = new Integer();
        System.out.println((String) obj);
    }
}