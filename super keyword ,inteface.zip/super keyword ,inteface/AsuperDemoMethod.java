class AsuperDemoMethod
{
void display()
{
System.out.println("A Display");
}
}
class SuperDemo2 extends AsuperDemoMethod
{
void display()
{
System.out.println("demo2 display");
}
void show()
{
display();
super.display();
}
public static void main(String[] args)
{
SuperDemo2 sd=new SuperDemo2();
sd.show();

}
}
