class AsuperDemoCons
{
AsuperDemoCons()
{
System.out.println("AsuperDemoCons constructer");
}
}
class SuperDemo3 extends AsuperDemoCons
{
SuperDemo3()
{
System.out.println("SuperDemo3");
}
public static void main(String[] args)
{
SuperDemo3 sd=new SuperDemo3();

}
}
