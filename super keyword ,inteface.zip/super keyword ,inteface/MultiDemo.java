interface A
{
 void run();
 }
interface B
 {
 void stop();
 }
class MultiDemo implements A,B
{
 public void run()
 { 
 System.out.println("running");
 }
public void stop()
 { 
 System.out.println("stopped");
 }
 public static void main(String[] args)
{
MultiDemo md=new MultiDemo();
md.run();
md.stop();
}
}