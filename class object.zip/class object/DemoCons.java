class DemoCons
{
	int empid;
	String name;
public DemoCons()
{
System.out.println("demo contructor");
}
public DemoCons( String name, int empid)
{
	this.name=name;
	this.empid=empid;
	System.out.println(empid + name);
}

public static void main(String[] args)
{
DemoCons t=new DemoCons();
DemoCons E1= new DemoCons("yash",101);
}
}
