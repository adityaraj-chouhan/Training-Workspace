public class Box
{ int x,y,z;
  Box(int l,int b ,int h)
  {
	  x=l;
	  y=b;
	  z=h;
  }
  int vol()
  {
  int v;
  v=x*y*z;
  return v;
  }
  public static void main(String[] args)
{
Box obj=new Box(10,20,30);
 System.out.println(obj.vol());
}
}
  