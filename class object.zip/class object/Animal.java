class Animal
{
void eat()
 {
 System.out.println("eating");
 }

public static void main(String[] args)
{
	System.out.println("hello");
Animal sheru= new Animal();
sheru.eat();

}}
