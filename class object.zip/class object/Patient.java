class Patient
{

String patienrName="abc";
double h=1.82;
double weight=73.2;
double computeBMI()
{
double x;
x=weight/(h*h);
return x;
}
 public static void main(String[] args)
 {
 Patient p=new Patient();
 p.computeBMI();
 System.out.println(p.computeBMI());
 }
 }
 